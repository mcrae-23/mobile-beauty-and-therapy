<?php
include('db_config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete appointment
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $appointmentId = $_GET['delete'];
    $deleteSql = "DELETE FROM appointments WHERE appointment_id = $appointmentId";

    if ($conn->query($deleteSql) === TRUE) {
        echo "Appointment deleted successfully!";
    } else {
        echo "Error deleting appointment: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

$conn->close();

