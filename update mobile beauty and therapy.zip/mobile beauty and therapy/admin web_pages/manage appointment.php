<?php
include('db_config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Form submission handling for updating appointment
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointmentId = $_POST["appointment_id"];
    $clientName = $_POST["client_name"];
    $appointmentDate = $_POST["appointment_date"];
    $appointmentTime = $_POST["appointment_time"];
    $service_type = $_POST["service_type"];
  


    $updateSql = "UPDATE appointments SET client_name='$clientName', appointment_date='$appointmentDate', appointment_time='$appointmentTime', service_type='$service_type'WHERE appointment_id=$appointmentId";

    if ($conn->query($updateSql) === TRUE) {
        echo "Appointment updated successfully!";
    } else {
        echo "Error updating appointment: " . $conn->error;
    }
}

// Fetch appointments from the database
$selectSql = "SELECT * FROM appointments";
$result = $conn->query($selectSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments - Mobile Beauty and Therapy</title>
    <link rel="stylesheet" href="styles.css"> <!-- Assuming you have a stylesheet file -->
</head>
<body>

    <header>
        <h1>Manage Appointments</h1>
    </header>

    <section>
    <?php
        // Display appointments in a table
        if ($result->num_rows > 0) {
            echo '<table>
                    <tr>
                        <th>appointment id</th>
                        <th>name</th>
                        <th>appointment date</th>
                        <th>Appointment Time</th>
                        <th>service_type</th>
                        <th>Status</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>';
            while ($row = $result->fetch_assoc()) {
                echo '<tr>
                        <td>' . $row['appointment_id'] . '</td>
                        <td>' . $row['name'] . '</td>
                        <td>' . $row['appointment_date'] . '</td>
                        <td>' . $row['appointment_time'] . '</td>
                        <td>' . $row['service_type'] . '</td>
                        <td>' . $row['status'] . '</td>
                        <td><a href="edit appointment.php?edit=' . $row['appointment_id'] . '">Edit</a></td>
                        <td><a href="delete appointment.php?delete=' . $row['appointment_id'] . '" onclick="return confirm(\'Are you sure you want to delete this appointment?\')">Delete</a></td>
                    </tr>';
            }
            echo '</table>';
        } else {
            echo "No appointments found.";
        }

       
        ?>
    </section>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Mobile Beauty and Therapy - Manage Appointments</p>
    </footer>

</body>
</html>
