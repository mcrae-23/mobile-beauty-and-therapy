<?php
// Admin credentials
$adminUsername = 'joyce 34';
$adminPassword = '$2y$10$e19x.TUUmUUGkPQ9aSblk.IUmTiKXO9kAIi/m8cm4p.UFaiPSTYyS';
?>