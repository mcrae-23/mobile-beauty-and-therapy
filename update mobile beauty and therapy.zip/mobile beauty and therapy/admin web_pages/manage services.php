<?php
// Database connection code (replace with your actual database credentials)
include('db_config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete service
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $serviceId = $_GET['delete'];
    $deleteSql = "DELETE FROM services WHERE service_id = $serviceId";

    if ($conn->query($deleteSql) === TRUE) {
        echo "Service deleted successfully!";
    } else {
        echo "Error deleting service: " . $conn->error;
    }
}

// Form submission handling for updating service
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $serviceId = $_POST["service_id"];
    $serviceName = $_POST["service_name"];
    $serviceDescription = $_POST["service_description"];
    $price=$_POST["price"];

    $updateSql = "UPDATE services SET service_name='$serviceName', service_description='$serviceDescription',price='$price' WHERE service_id=$serviceId";

    if ($conn->query($updateSql) === TRUE) {
        echo "Service updated successfully!";
    } else {
        echo "Error updating service: " . $conn->error;
    }
}

// Fetch services from the database
$selectSql = "SELECT * FROM services";
$result = $conn->query($selectSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Services - Mobile Beauty and Therapy</title>
    <link rel="stylesheet" href="styles.css"> <!-- Assuming you have a stylesheet file -->
</head>
<body>

    <header>
        <h1>Manage Services</h1>
    </header>

    <section>
        <?php
        // Display services in a table
        if ($result->num_rows > 0) {
            echo '<table>
                    <tr>
                        <th>Service ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Price</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>';
            while ($row = $result->fetch_assoc()) {
                echo '<tr>
                        <td>' . $row['service_id'] . '</td>
                        <td>' . $row['service_name'] . '</td>
                        <td>' . $row['description'] . '</td>
                        <td>' . $row['price'] . '</td>
                        <td><a href="edit service.php?edit=' . $row['service_id'] . '">edit</a></td>
                        <td><a href="delete service.php?delete=' . $row['service_id'] . '" onclick="return confirm(\'Are you sure you want to delete this service?\')">Delete</a></td>
                    </tr>';
            }
            echo '</table>';
        } else {
            echo "No services found.";
        }

        // Display form for editing a service
        if (isset($_GET['edit']) && !empty($_GET['edit'])) {
            $editServiceId = $_GET['edit'];
            $editSql = "SELECT * FROM services WHERE service_id = $editServiceId";
            $editResult = $conn->query($editSql);

            if ($editResult->num_rows > 0) {
                $editRow = $editResult->fetch_assoc();
                echo '<form method="post" action="">
                        <input type="hidden" name="service_id" value="' . $editRow['service_id'] . '">
                        <label for="service_name">Service Name:</label>
                        <input type="text" id="service_name" name="service_name" value="' . $editRow['service_name'] . '" required><br>
                        <label for="service_description">Service Description:</label>
                        <textarea id="service_description" name="service_description" required>' . $editRow['service_description'] . '</textarea><br>
                        <input type="text" name="price" value="' . $editRow['price'] . '">
                        <label for="price">Price:</label>
                        <input type="submit" value="Update Service">
                    </form>';
            } else {
                echo "Service not found for editing.";
            }
        }
        ?>
    </section>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Mobile Beauty and Therapy - Manage Services</p>
    </footer>

</body>
</html>
