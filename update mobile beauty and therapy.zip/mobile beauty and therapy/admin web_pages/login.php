

<?php
session_start();
require_once 'db_config.php';


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to securely hash passwords
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Function to check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Function to redirect to login if not logged in
function redirectToLogin() {
    header("Location: login.php");
    exit();
}

// Admin login form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM admins WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            // Admin login successful, set session variables
            $_SESSION['admin_id'] = $row['admin_id'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "Admin not found.";
    }

    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mobile Beauty & Therapy</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Your styles go here */
    </style>
</head>
<body>
    <header>
    <h2>LOGIN</h2>
    <nav>
        <ul>
           <a href="admin_setup.php">Admin setup</a>
           <a href="admin_Dashboard.php">Admin Dashboard</a>
            
        </ul>
    </nav>
    </header>
    
    
  

    <!-- Your login form goes here -->

    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>

        <?php
            if (isset($error)) {
                echo '<p style="color: black;">' . $error . '</p>';
            }
        ?>
    </form>

    

    <!-- Add a link to the registration page if needed -->

</body>
</html>

    

