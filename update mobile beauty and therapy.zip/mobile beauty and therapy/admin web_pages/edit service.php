<?php
// Include database connection file
include('db_config.php');

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted for updating service
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $serviceId = $_POST["service_id"];
    $serviceName = $_POST["service_name"];
    $description = $_POST["description"];
    $price = $_POST["price"];

    // Update service in the database
    $updateSql = "UPDATE services SET service_name='$serviceName', description='$description', price='$price' WHERE service_id=$serviceId";

    if ($conn->query($updateSql) === TRUE) {
        echo "Service updated successfully!";
    } else {
        echo "Error updating service: " . $conn->error;
    }
}

// Fetch service details for editing
if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    $editServiceId = $_GET['edit'];
    $editSql = "SELECT * FROM services WHERE service_id = $editServiceId";
    $editResult = $conn->query($editSql);

    if ($editResult->num_rows > 0) {
        $editRow = $editResult->fetch_assoc();
    } else {
        echo "Service not found for editing.";
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service - Mobile Beauty and Therapy</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1>Edit Service</h1>
</header>



<section>
    <form method="post" action="">
        <input type="hidden" name="service_id" value="<?php echo $editRow['service_id']; ?>">
        <label for="service_name">Service Name:</label>
        <input type="text" id="service_name" name="service_name" value="<?php echo $editRow['service_name']; ?>" required><br>
        <label for="service_description">Service Description:</label>
        <textarea id="service_description" name="description" required><?php echo $editRow['description']; ?></textarea><br>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo $editRow['price']; ?>" required><br>
        <input type="submit" value="Update Service">
    </form>
</section>

<footer>
    <p>&copy; <?php echo date('Y'); ?> Mobile Beauty and Therapy - Edit Service</p>
</footer>

</body>
</html>
