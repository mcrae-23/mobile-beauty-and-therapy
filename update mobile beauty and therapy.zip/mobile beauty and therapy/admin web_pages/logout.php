<?php
session_start();

// Destroy the session variables

session_destroy();

// Redirect to the login page or another suitable page
header('location: login.php');
exit();
