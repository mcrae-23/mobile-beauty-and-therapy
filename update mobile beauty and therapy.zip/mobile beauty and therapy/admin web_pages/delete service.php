<?php
include('db_config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete service
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $serviceId = $_GET['delete'];
    $deleteSql = "DELETE FROM services WHERE service_id = $serviceId";

    if ($conn->query($deleteSql) === TRUE) {
        echo "Service deleted successfully!";
    } else {
        echo "Error deleting service: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

$conn->close();

