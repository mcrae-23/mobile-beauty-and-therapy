<?php
include('db_config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointmentId = $_POST["appointment_id"];
    $name = $_POST["name"];
    $appointmentDate = $_POST["appointment_date"];
    $appointmentTime = $_POST["appointment_time"];
    $service_type = $_POST["service_type"];
    $Status=$_POST['status'];

    $updateSql = "UPDATE appointments SET name='$name', appointment_date='$appointmentDate', appointment_time='$appointmentTime', service_type='$service_type', status='$Status' WHERE appointment_id=$appointmentId";

    if ($conn->query($updateSql) === TRUE) {
        echo "Appointment updated successfully!";
    } else {
        echo "Error updating appointment: " . $conn->error;
    }
}

// Fetch appointment details
if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    $editAppointmentId = $_GET['edit'];
    $editSql = "SELECT * FROM appointments WHERE appointment_id = $editAppointmentId";
    $editResult = $conn->query($editSql);

    if ($editResult->num_rows > 0) {
        $editRow = $editResult->fetch_assoc();
    } else {
        echo "Appointment not found for editing.";
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment - Mobile Beauty and Therapy</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <header>
        <h1>Edit Appointment</h1>
    </header>

    <section>
        <form method="post" action="">
            <input type="hidden" name="appointment_id" value="<?php echo $editRow['appointment_id']; ?>">
            <label for="name">Client Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $editRow['name']; ?>" required><br>
            <label for="appointment_date">Appointment Date:</label>
            <input type="date" id="appointment_date" name="appointment_date" value="<?php echo $editRow['appointment_date']; ?>" required><br>
            <label for="appointment_time">Appointment Time:</label>
            <input type="time" id="appointment_time" name="appointment_time" value="<?php echo $editRow['appointment_time']; ?>" required><br>
            <label for="service_type">Service:</label>
            <input type="text" id="service_type" name="service_type" value="<?php echo $editRow['service_type']; ?>" required><br>
            <label for="Status">Status:</label>

            <select name="status" value="<?php echo $row['status']; ?>">
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="cancelled">Cancelled</option>
            </select>
            <input type="submit" value="Update Appointment">
        </form>
    </section>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Mobile Beauty and Therapy - Edit Appointment</p>
    </footer>

</body>
</html>
