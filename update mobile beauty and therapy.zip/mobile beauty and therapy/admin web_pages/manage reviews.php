<?php
// Start session to maintain admin login state
session_start();



// Include database connection file
include "db_config.php"; // Assuming this file contains code to connect to your database

// Check if the form is submitted to add admin reply
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reply'])) {
    // Retrieve review ID and admin reply from the form
    $review_id = $_POST['review_id'];
    $admin_reply = $_POST['admin_reply'];

    // Update the review in the database with the admin's reply
    $sql = "UPDATE reviews SET admin_reply = ? WHERE review_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $admin_reply, $review_id);
    
    if ($stmt->execute()) {
        // Reply successfully updated
        $_SESSION['reply_success'] = "Admin reply added successfully.";
    } else {
        // Failed to update reply
        $_SESSION['reply_error'] = "Failed to add admin reply. Please try again.";
    }

    // Redirect back to the manage reviews page
    header("Location: manage_reviews.php");
    exit();
}

// Fetch reviews from the database
$sql = "SELECT * FROM reviews";
$result = mysqli_query($conn, $sql);

$reviews = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $reviews[] = $row;
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reviews</title>
    <style>

        :root{
            --blue:#00b8b8;
            --black:#333;
            --white:#ffff;
            --light-color:lightgrey;
            --light-bg:#eeee;
            --border:.2rem solid rgba(0,0,0,.1);
            --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);

        }

        *{
            font-family: Arial, Helvetica, sans-serif;
            margin:0;
            padding:0;
            box-sizing: border-box;
            outline:none;
            border:none;
            text-decoration: none;
            text-transform: capitalize;
        }
        *::-webkit-scrollbar{
            height: .5rem;
            width: 1rem;
        }
        *::-webkit-scrollbar-track{
            background-color: transparent;
        }
        *::-webkit-scrollbar-thumb{
            background-color: aqua;
            border-radius: 5px;
        }

        html{
            font-size:62.5%;
            overflow-x: hidden;
            scroll-behavior: smooth;
            scroll-padding-top: 6.5rem;
        }
        section{
            padding:7rem 2rem;
        }
                /* Global styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
        }
        .container div {
            border: 1px solid #ccc;
            padding: 10px;
        }


        /* Header styles */
        header {
            background-color:var(--blue);
            color: #fff;
            padding: 10px 0;
            text-align: center;
            font-size: 1.8rem;
        }

        header h1 {
            margin: 0;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
            display: inline;
            margin-right: 20px;
            
        }



        nav ul a {
            color: #fff;
            text-decoration: none;
        }

        nav ul  a:hover {
            text-decoration: underline;
        }

        /* Review styles */
        .container h2 {
            margin-top: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            font-size: 1.4rem;
        }

        strong {
            font-weight: bold;
            font-size:1.5rem;
        }

        .admin-reply {
            margin-top: 10px;
        }

        textarea {
            width: 100%;
            height: 100px;
            margin-top: 10px;
        }

        button {
            padding: 5px 10px;
            background-color:var(--blue);
            color: #fff;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color:var(--blue);
        }



    </style>
    
</head>
<body>
    <header>
        <h1>Manage Reviews</h1>
        <nav>
            <ul>
                <a href="admin_dashboard.php">Home</a>
                <a href="logout.php">Logout</a>
            </ul>
        </nav>
    </header>

    <section class="container">
        <h2>Reviews</h2>
        <?php if (!empty($reviews)): ?>
            <ul>
                <?php foreach ($reviews as $review): ?>
                    <li>
                        <strong>Username:</strong> <?php echo $review['username']; ?><br>
                        <strong>Comment:</strong> <?php echo $review['comment']; ?><br>
                        <strong>Rating:</strong> <?php echo $review['rating']; ?><br>
                        <?php if (!empty($review['admin_reply'])): ?>
                            <div class="admin-reply">
                                <strong>Admin:</strong> <?php echo $review['admin_reply']; ?>
                            </div>
                        <?php else: ?>
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <input type="hidden" name="review_id" value="<?php echo $review['review_id']; ?>">

                                <textarea name="admin_reply" placeholder="Reply to this review"></textarea>
                                <button type="submit" name="reply">Reply</button>
                            </form>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No reviews found.</p>
        <?php endif; ?>
    </section>
</body>
</html>
