<?php
// Check if the setup has already been completed
include('db_config.php'
);



if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to securely hash passwords
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST["full_name"];
    $username=$_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Check if passwords match
    if ($password != $confirm_password) {
        echo "Passwords do not match.";
    } else {
        // Hash the password before storing in the database
        $hashed_password = hashPassword($password);

        // Insert user data into the database
        $sql = "INSERT INTO admins (full_name, username, email, password) VALUES ('$full_name','$username', '$email', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "Registration successful!";

            header('location: login.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Setup - Mobile Beauty and Therapy</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <header>
        <h2>MOBILE BEAUTY AND THERAPY <span>Admin Setup</span> </h2>
    </header>
    

    <section>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type ="text" placeholder="admin fullname" name="full_name" required><br>
            <input type="text" placeholder="admin username" name="username" required><br>
            <input type="email" placeholder="email"name="email" required><br>
            <input type="password" placeholder="admin password" name="password" required><br>
            <input type="password" placeholder="confirm  password" name="confirm password" required><br>

            <input type="submit" value="Complete Setup">
        </form>
    </section>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Mobile Beauty and Therapy - Admin Setup</p>
    </footer>

</body>
</html>
