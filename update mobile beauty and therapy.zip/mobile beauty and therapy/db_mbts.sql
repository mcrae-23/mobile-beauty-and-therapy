CREATE DATABASE IF NOT EXISTS mobile_beauty_therapy;

USE mobile_beauty_therapy;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL
    password VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO `users` (`user_id`, `username`, `phone`, `fullname`, `password`, `email`) VALUES 
('1','whitney ','0740335702','whitney britney','60fce90l','wbritney@gmail.com');


-- Create the services table
CREATE TABLE IF NOT EXISTS services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO 'services'( ) VALUES()
-- Appointments table
-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(255),
    username VARCHAR(255),
    address VARCHAR(255),
    location VARCHAR(255),
    appointment_date DATE,
    appointment_time TIME,
    service_type VARCHAR(255),
    
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create payment table
CREATE TABLE IF NOT EXISTS payment (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT,
    item_number VARCHAR(255),
    item_name VARCHAR(255),
    payment_status VARCHAR(255),
    payment_amount DECIMAL(10, 2),
    payment_currency VARCHAR(255),
    txn_id VARCHAR(255),
    receiver_email VARCHAR(255),
    payer_email VARCHAR(255),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id)
);

-- Add any additional SQL queries or modifications as needed

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    photo BLOB NOT NULL,
    username VARCHAR(255) NOT NULL,
    appointment_id INT,
    rating INT,
    comment TEXT,
    admin_reply VARCHAR (255) DEFAULT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id)
);
-- Create the admin database
CREATE DATABASE IF NOT EXISTS admin_system;

-- Use the admin database
USE admin_system;

-- Create the admins table
CREATE TABLE IF NOT EXISTS admins (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the roles table
CREATE TABLE IF NOT EXISTS roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) NOT NULL
);

-- Create the admin_roles table to link admins to roles
CREATE TABLE IF NOT EXISTS admin_roles (
    admin_id INT,
    role_id INT,
    PRIMARY KEY (admin_id, role_id),
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Create the permissions table
CREATE TABLE IF NOT EXISTS permissions (
    permission_id INT PRIMARY KEY AUTO_INCREMENT,
    permission_name VARCHAR(50) NOT NULL
);

-- Create the role_permissions table to link roles to permissions
CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INT,
    permission_id INT,
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (permission_id) REFERENCES permissions(permission_id)
);

-- Create the logs table
CREATE TABLE IF NOT EXISTS logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT,
    action_description TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id)
);

CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 6) NOT NULL,
    longitude DECIMAL(10, 6) NOT NULL,
    last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE PaymentMethods (
    method_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    method_type ENUM('PayPal', 'M-Pesa') NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    -- Add other payment method-related fields as needed
);
INSERT INTO PaymentMethods (user_id, method_type, account_number) VALUES
    (1, 'PayPal', 'user1@example.com'),
    (2, 'M-Pesa', '0712345678');