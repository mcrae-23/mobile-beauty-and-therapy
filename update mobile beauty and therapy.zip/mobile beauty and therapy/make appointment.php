<?php
// Start session to maintain user login state
session_start();

// Include database connection file
include "db_config.php"; // Assuming this file contains code to connect to your database

// Define a variable to hold the success message
$successMessage = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve appointment details from the form
    $name = $_POST['name'];
    $username = $_POST['username'];
    $address = $_POST['address'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $location = $_POST['location'];
    $service_type = $_POST['service_type'];

    // Insert the appointment into the database
    $sql = "INSERT INTO appointments (name, username, address, appointment_date, appointment_time,  location, service_type) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssss", $name, $username, $address, $appointment_date, $appointment_time, $location, $service_type);
    mysqli_stmt_execute($stmt);

    // Check if the appointment was successfully inserted
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        // Appointment booked successfully, set success message
        $successMessage = 'Appointment booked successfully!';
    } else {
        // Appointment booking failed
        $errorMessage = 'Failed to book appointment. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="logins.css">
    <title>Make Appointment</title>
</head>
<body>
    <header> 
        <h1>Make an Appointment</h1>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="logout.php">Logout</a></li>
                <li><a href="appointment.php">Your Appointments</a></li>
            </ul>
        </nav>
    </header>

    <section class="container">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label>Enter your name</label>
            <input type="text" id="name" name="name" required><br> 

            <label>Enter your username</label>
            <input type="text" id="username" name="username" required><br> 

            <label>Enter your Address</label>
            <input type="text" id="address" name="address" required><br>

            <label>Enter your Location</label>
            <input type="text" id="location" name="location" required><br>
          
            <label>Select appointment date</label>
            <input type="date" id="appointment_date" name="appointment_date" required><br>
            
            <label>Select appointment time</label>
            <input type="time" id="appointment_time" name="appointment_time" required><br>
            
            <label>Select service</label>
            <select id="service" name="service_type" required><br>
                <option value="Massage">Massage</option>
                <option value="Spa">Spa</option>
                <option value="Surgery and Facial Therapy">Surgery and Facial Therapy</option>
                <option value="Skin Care">Skin Care</option>
                <option value="Waxing Salon">Waxing Salon</option>
                <option value="Botox">Botox</option>
                <option value="BarberShop">BarberShop</option>
                <option value="Tattoo and Piercing">Tattoo and Piercing</option>
                <option value="Tanning Studio">Tanning Studio</option>
                <option value="Makeup">Makeup</option>
                <option value="Personal trainer">Personal Trainer</option>
                <option value="Weight Loss">Weight Loss</option>
                <option value="Gym and Fitness">Gym and Fitness</option>
                <option value="Beauty Salon">Beauty Salon</option>
                <option value="Eye brows and Lashes">Eye brows and lashes</option>
                <option value="Psychological Therapy">Psychological Therapy</option>
                <option value="Orthopedic Therapy">Orthopedic Therap</option>
                <option value="Hair Salon">Hair Salon</option>
                <option value="Manicure and Pedicure">Manicure
              </select>

              <?php if (!empty($successMessage)): ?>
                  <p style="color: aqua;"><?php echo $successMessage; ?></p>
              <?php endif; ?>


              <button type="submit" class="submit">BOOK NOW</button>
              </form>
</section>
</body>
</html>