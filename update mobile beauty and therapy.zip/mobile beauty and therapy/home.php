<?php 
include('db_config.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport"content="width=device-width, intial-scale=1.0">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  
  <div class="image-container">
    <div class="header align-items-top">
      <a href="home" class="logo">MOBILE BEAUTY AND THERAPY</a>

      <a href="#home">HOME</a>
      <a href="services.php">SERVICES</a>
      <a href="register.php">REGISTER</a>
      <a href="login.php">LOGIN</a>
      

    </div>


     
        

        
  </div>
  <section class="welcome" id="welcome">
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="welcome-box">
          <h2>Welcome to Mobile Beauty and Therapy</h2>
          <p>Welcome to Mobile Beauty and Therapy, your sanctuary for mobile beauty and wellness.</p>
          <p>Discover a world of relaxation, rejuvenation, and self-care where your inner and outer beauty are celebrated.</p>
          <p>We're here to provide you with expert beauty and therapy services that leave you feeling refreshed and revitalized.</p>
        </div>
      </div>
      
      <div class="col">
        <div class="welcome-box">
          <h2>Why Choose Us</h2>
          <ul>
            <li>Experienced Professionals</li>
            <li>Convenient Mobile Services</li>
            <li>High-Quality Products</li>
            <li>Customized Treatments</li>
            <li>Excellent Customer Service</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>




 <!-- service  section starts -->
 <section class="service" id="service">
    <div class="service" id="service">
      <div class="conatiner">
        <span>Massage and Therapy</span>
        <div class="service-container">
          <img src="images\massage.jpg" alt="">
        <div class="service-box">
          <p>Alleviate muscle tension and soreness for improved flexibility and mobility.</p><br>
          <p>Reduce stress and anxiety levels, promoting a sense of calm and relaxation.</p><br>
          <p>Improve circulation and lymphatic drainage for enhanced detoxification and healing.</p><br>
          <p>Customize your massage experience with a variety of techniques and pressure levels to suit your needs.</p><br>


          </div>
        </div>
      </div>

    </div>
    <div class="service" id="service">
      <div class="conatiner">
        <span> Psychological Therapy</span>
        <div class="service-container">

        <img src="images\psychology image.jpg" alt="">
          <div class="service-box">
          <p>Gain insight into your thoughts, feelings, and behaviors to foster self-awareness and personal growth.</p><br>
          <p>Develop effective coping strategies to manage stress, anxiety, depression, and other mental health concerns.</p><br>
          <p>Build resilience and improve your overall quality of life through therapy and counseling.</p><br>
          <p>Receive individualized support and guidance in a safe and confidential environment.</p><br>

          </div>
        </div>
      </div>

    </div>
    <div class="service" id="service">
      <div class="conatiner">
        <span> Beauty Salon </span>
        <div class="service-container">
          <img src="images\beauty salon.jpg" alt="">
          <div class="service-box">
          <p>Treat yourself to a day of pampering and relaxation in our stylish and modern salon environment.</p><br>
          <p>Receive personalized consultations and recommendations from our team of skilled professionals.</p><br>
          <p>Enhance your natural beauty with expertly executed haircuts, colors, facials, and makeup applications.</p><br>
          <p>Enjoy top-of-the-line products and techniques that deliver stunning results while nourishing and protecting your skin and hair.</p><br>
              
          </div>
        </div>
      </div>

    </div>
    <div class="service" id="service">
      <div class="conatiner">
        <span> Gym and Fitness</span>
        <div class="service-container">
          <img src="images\gym and fitness.jpg" alt="">
          <div class="service-box">
          <p>Access to cutting-edge equipment and facilities to support your fitness journey.</p><br>
          <p>Work with certified personal trainers who provide individualized workouts and support.</p><br>
          <p>Participate in a variety of group fitness classes for motivation, accountability, and fun.</p><br>
          <p>Enjoy a supportive and inclusive community that encourages and inspires you to succeed.</p><br>
          </div>
        </div>
      </div>

    </div>
 </section>
        
      
    <!-- service section ends -->

    <!-- safety measures starts -->
    <section class="safety-measures" id="safety-measures">
      <h1 class="heading">Safety Measures</h1>
      <div class=" box-container container">
        <div class="box" >
        <h3>Trained professionals</h3>
        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEBUQExAVFRIVEBcVEhUWFRUVFRUYFRYXFxUWFxUYHSggGBolHRcVITEiJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGxAQGi0lICUvKy0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgEDBAUHAgj/xABHEAABAwICBQgGCAUACwEAAAABAAIDBBEFIQYHEjFBE1FhcYGRobEiMnKCwdEUIzNCUmKisnODkuHwNDVDRFNjk7PCw/EV/8QAGwEBAAMBAQEBAAAAAAAAAAAAAAMEBQYCAQf/xAA1EQACAQMBBAgFBAEFAAAAAAAAAQIDBBEhBRIxQTIzUWFxgZGhEyKxwdEjQuHw8RU0Q0RS/9oADAMBAAIRAxEAPwDuKIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIClkREBVERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAERUugKoqKqAIiIAiIgCIiAIiIAiIgKIiICqIiAIiIAiIgCIiAIiIAiIgCIqIDRaXaTw4ZTmeY3JOzHGCNuR34W37yeAXAdJNPa+ucS+d0Ud/RhhcWNb1ubZz/ePYF40/x6Wur5XvvsxyOhhZmQ1rHlu7i5xFzx3DgtXi2B1VJsmop3xB/qFwFjxtcEgO6DmoJyb4F2lSUVmXEpRYxUwO2oqmZjgb3bK/xBNj2ro+h+t+VhEVeOUZu5djQHt9tgycOloB6CuUovCm0SSpxlxR9EaU6yaekh5SBv0kkN2SxwEQ2txdJn3AHPLJc2n1w4mXXaIGtvk3knOHUSXXKj+jlRygNG4EiS4jAuSSd7QPEdIWsxjCJqOXkZ4yx+yHAG3pNcSGu38bHuKt3EYqnCpTejWGuakuPl2FO01qTpVY6p5T1w4vh5rXJ2DRDXBHM9sNYxsLnZNmafqieAeDnH15hdWB4r46/wrtmpLS18zXYfM4udGzbp3EkksBAcwnjslzbdBtwUFOpnRk1egoreidaREUxUCIiAIiIAioiAqiIgC1OlGL/QqOaq2drkYy/Zvs7RG5t7G1zluW2UN1vAnBKu34GdwljJ8Lr7FZaQInS69ID9pQTN9iSN/wC7ZW2pddGGOHpCojPM6La8WEr57RXXbwIfiM+mabWjhEhAFaGk/jjmjH9T2AeK21LpdQzG0NXFK6xOzG8PdYb8gvlBSDV9VclidO7g55jP8xjmjxIVe4oblKUoPVJv0JKc05pPgfR02On7jLdLj8B81jOxeY/eA6m/O6wEXITva8nlzflobKt6a5GaMVm/H+kfJXWY1KN4aewha1F5jd11wmz66NN/tRv4McYfWaW9I9IfPwWxhma8Xa4EdCh69RvLTdpIPOFcpbUqRfzrK9H+CCdnF9F49yN6R6uHNxKKvp2h0DqlklTFkCw7V3SNB3tvYkbxnv4SnE8OiqonQTRh8b97TvB4Oad7XDgRuWfBixc0skGZaQHDjllcfELCEDSwwlt49kMsSTduyBYuJucuN7rWo1oVY70H4niMZrSRxnTTQV9BsyxvMsD5AwXAEjHO9VrrZOvmA4W6VosbwGqonNbUwGMvBLPSa5rrW2gHMJFxcXC75idIyqhkp33DXtsCLXaQQWvF8tprg0jqUL1xYlGKeOlcCZ3PbK0gCzWtu1xJvcF1yAM16cVxJfmTwzldFVuhljmabOjka8HpY4H4WUz11ybWLX4fRIbdR2z8SoXSUzppGQtF3SSNjaOcvcG/FT/XpRcniELwPRfRNaDzuie8O8HMXldBnnT4kfM5uFOdS7CcYiI3CGUu6tm3mQoMuz6gsGtHPXOGb3CGP2Wek89riB7q+U1mR6ryxTZ19ERWjMCIiAIiICiKqIAiIgCj+n1MZcLrIwMzSSW6w0keSkCtVEIkY5jhdrmlrhzhwsUB8bg3zVVcqaYwvfC71o3ujd1scWnyVtauclcK5TVBikZKN8cjXj3HB3wVteSmE9GD6Xa8OAcNzgHDqIuPAqqsaMUEv0KnY4DlI4GRuIILXBg2WPa7iHNDSOtZD2kGxBB5jvX5/c20qEmnw5PkdDCaku8oiIq5IEREABW2BjMW0D6d7WJ78lqVcjlLd3cr1jdKhJqXB+xFUhvcGZig+n2g1RiU8UtO6LabEY3tke5lwHFzS2zTf1nX3cN6msLy4Xt1LNpKJz8/VHPx7FvU5qpFSXBlefy9xEdXurMUEgqqmRstQ0Hkwy/JxXBBcC4AudYkXsLX3cV611aPvqaNtRG3akpnFzgMyY3Cz7c9iGu6gV0VosBnfp5163qXdWMFJVJb28+J8dhfRmpqRpwanAIuHzh/QeXkOfYW94Wu0m1Q0tS8y08jqZ7jdzWtD4iTvIYSNjPmNuhZWgui0+DNlElWyWB9nCMRlrhIMrtJcd43joBUSXw8uXDtLNWpGrFKPHsJ+qbQ51FKuvfIczYcGjIf3WNZZ09rRTxCOV3vHt+T7GyeNWTVVURpq2SP1Xm3Mcx47lv8PxBsuW54GbfiOcK1bX9Os93g+whq28qevFGeiIrxAEVEQFUREAREQHy9rVw36Ni9S0CzZHCdvVKAXfqD1FF1PXvRXniqwPvOp3e76bP/AGLliu2tZVaSku9ejwRVYOEsMIt7guidTWwPmpgyUxv2ZIg8NlFxdrgH2Dgc9xvkVXGdDq2l2Nune9r4hIHRse8NuBtNfYXY5pNjfsUu/HOM6nzcljODsmpnG/pOGthJ+spnck7nLN8R7rt9xTeop2yCzh1HiOorgOpfGPo+KCEmzaiN0TgcrOaDJGSOxw95fQaz68I7zg1lE0JNYfMjtXSujNjmDuPA/wB1ZUlmiD2lpGR8OkdKj9VTmN2yew84XNX1k6L3o9F+3calvX+Jo+JaRFepaZ0hsN3E8B8z0KjCEpvdisssNqKyy0xpJsBcncAtpTYaGjakO4X2Ru7TxWZS0rYxkM+JO8/26Fkcht2B9W9z023Bblts2MPmq6vs5L8/Qz6t05PEdF28zGoqLaO24Wbwba3hzLagJZVWolgqyk5PIVAqqnHsX08nl7gBc7uKi2JVnKvv90ZN+J7VttIHERixyLrO6cifgo+sPaleW98JcNG+8v2lNY3wijmk2lLaV3JRtD5rXde+xHfde2ZJ32Hatbg+nO04MqWNaCbcozaAb7TSTl0grNVGbWcGmreo47yWn95E1XqN5aQ5psQcivP+BFEnzRDxJZQ1QlYHjqI5jxWUo7gFRaQs4OFx1j+3kpEups6/xqSk+PB+JkVqe5NooiqitEQREQBERfVxBy/WJhpqqKpYBd7S6VntRuLrdoDh2rgQK+nqsWlf/Ed5lfO2k+FfQ6uanA9Fj7x+w70meBt2FU9hVvmqUX25X0f2ZYvqekZrswWsDxmeimE8Emy8ZOG9r27y17fvN/zJfQurTTCLEoT6rKlv20QJta5DXMvmWnwJsV8zmQc471sMGlqIpWT03KCVjrsfG1zrHsBBB3EHetqrSUuOjKUJyXy8j6trsDpp3NfLTxuexwcx5aA9pBuC14zHesswWGR7/movoBpY+vhAnppIKljRth0bmRyfnjLuHO3eOnepes/Cz7EuphuaRvWPWUwkbbjvaeY/JbQi6sSQ83cvk4KcXGXBn2MnF5RHaPD3PPpXa0Gx5yRwHzW6jYGgNAsBwXoooLa1hQWI8eb5klWtKo9SrG3NlltFslbgZYX4lXlZIgiIgCoFRx/svSA1mPj6nqcPl8VEMWrxTwSTHPYbcD8Tjk1vaSFM8abeB3RY+IXJdY9ZZsUA+8TI7qb6LB3lx7Fg7Qp71yk+xe2TX2dH4mI95CJpXPcXuN3OcXOPOSbkrwqIvL1OmOi6A4mZYXQOPpQ22efk3eqOwgjqspSuXaF1fJVsfNJeJ3vC7f1BveuoqncRxPPaY91BQqPHPX8+5cppNh7Xczgey+fhdTEKElS+jftRsdztHktLZM+lHwf2Mi9XRZkIqItoolUREARFRARXFmWmd0kHvH/1aaswammfystNFJIAGhz2Nc6w3C56ypLpFFZ7X842T2ZjzK1C5a5UqVeeNNfrqa9HE6ayY8FFEz1IY2+zGxvkFk7R51RFVbzxJcYKhxve+Y3Hit7huK7XoSGzuDuDvkVoVRT21xOhLMPNdpHVpRqLDJsqqO4fixZ6L828HcR184W+jkDgCCCDuIXSW91TrrMfTmZdSlKm8Mq+MFWWwm9juWSvD93VmrBGe0REAXl7rC6PdYXWOLvPR5IC5Hn6R7FeVAFVAYmKNvC8flJ7s1wLTOq5SulzyZsxt91o2v1Fy+hHNvlwIN+1fM9e5xmkL/X5R210HbNx3rMvYfOp92Pc3diLWfd9/wDBjoiKkdAe4pjGRIN7HB462naHku17QOY3HMdRzC4kuvaPy8pSQP4mBl+sDZPiFXuVomUL5aRfiZ6lGDOvA3ouO4kKLqR4Afqepx+fxU+yn+s13P6ow7xfJ5myRVRdCZoVCqrX4zOWRG29x2R27/C68VJqEXJ8EeoxcmkjDxDFzcsj4ZF3y+a1TqmQ5l7/AOo/BWkXLVrmrVlmUvLka0KMILCRffVPc3Zc4uF7i+ZB61YRFDKTlxeSRJLgERF8PoREQBX6SsfEbtOXFp3H5HpVhF6jOUHvReGfHFSWGSaixNkmV9l3MfgeKzn7lCllRV8rBYPNumxt3rWo7VwsVV5r8FKpZ/8Ah+pLV4e4AKLNqpnkNEjiTkLG3kt3TQbIDQSTxJJNzxK0La7Vdvdi0lzePT+8CtVounxepdc4uPksmNlgqRx261cVshCLy48OKoRw70Abzr5603peRxKpjtYcttDqe1sn/mvoZ25ca1xUmxXMl/4sA743EHwc1VbyOaeew1tjzxXce1P2wyBIiLJOnC6joRJtUEf5XSN7nuPxXLl0fV5JekcPw1Dh3tY74qGv0PNFO9X6ee8k6kOj32R9s+QUeUh0f+yPtnyC97L/ANx5P7GDd9V5o2qIi6MzAtLpHuZ7R8lulq8fivFtfhcD2HIqpfRcreaXYTW7xViR1ERcua4REQBERAEWFjOKx0cD6iUnYYBkPWcSbNa0cSSfM8FyfFtZtbKSIQynZws0SSdr3ggdgCuWthWudYLTtfD8kFa4hS0kdmDSeBVmaoYz15GN9pzW+ZXzzW41Vz/a1Uz78DI639INvBa8xXzPzWrDYEv3VPRfyipLaPZH3PoebSahZ61dTgjeOWYT3ArEk02w4f77GfZD3d1m5rggjU31O4TFU4rG2Vu02ON8zWncXsLQwkcQC6/WApv9CpRWZTfsvszwr+bfBHf8Fo/QEhBBe0HMEENOYBBzB57rcNAGQVQFVWKVKNKChHgiGc3N5YREUh5PHV2legLKq8kX6kBQZ58OC51roo708M9vUlLCeh7b+bGrpCi+sik5XDajnYwSj+WQ4+AKjrR3oNFmzqfDuIS7/ro/Y4GirZUWGdoF0DVu76mUf84HvjA+C5+p5q1PoTj88Z/S75KOt1b/ALzK131T8iZKRaPfZH2z5BR1STAB9T77vNetl9f5P7HPXfV+aNiiqi6IzArcsYc0tO4gg9quIvjWQQ2pgMbyw7we8cCrakeLUPKN2mj02+I5vko4uXu7Z0KmOXL+9xr0avxI558wiIqpMEREBy7W9jJdIyhb6rQ2aU87nbQY3qAz94cy50pPrMv/APqTX/DHbq5NtlGF3ezqcadrBR5pPzepgXMnKrJvtCIiukAU81HyhuMMB+/TzNHc13k0qBqUarakRYzRvO7lXM/6kUkY8XBR1VmDPUeJ9SIiLOJwiIgCIiALFxClEsUkThcSRuYR0OaQfNZSpdAfL0kZa4sO8OLT1tNj5Lyt3prR8jiNTHbLly9vVLaTzcVpFhTWJNHdU5/Egp9qT9UFONWp/wBIH8M/vUHU21a+tP7Mfm9QVegyG76l+X1JwpNgX2Det37iowFKMFH1De39xUmyuufg/qjnbzoLxM5ERdAZpVERAUK0uMYdvlYM/vjn6R0rdooa9CNaG5L/AAe6dRwlvIhKLdYphd7yRjPe5vP0jp6FpFzFehOjLdn69prU6sakcoqiIoSQ4/rdpdivbJbKWmb3xlzT4bPeoSuta4MP26WKoAzhm2XezKAP3BneuSrttk1fiWkO7T0/jBhXcN2q+/UIioVpFYqrlLUOikZKz145GyM9pjg4eIXR9ANG6GuoA+WC8zJXse9r3tcc9pt7Ot6rgN3BbWo1X0Ljdr6hnQJGOH62E+Kyqm2LenOVOakmnh6J/ctxs6koqUcHXcExFlVTxVMZuyWNr2+8L2PSN3Ys9chw6pfo/E1jJH1FNJMfqpLNdG4t2i6N7eBtm0i188s772DWtRn14qhh4+jG4d7X38FBC5ozWYy09CwrG4a3lBtd2p0FFBna0aADITnoEY+LgsKbWzTfcp53H83JMHg9y9fHpr9yPqsLl/8AG/Q6Mi49W62Kh1xFTxM32L3OkPRkNkDxUbxLTOuqLh1S8NP3Y7Rt/R6XeVFK8prhqWaeyLiXSwvP8ZO3Y1pFS0g+unYw8G3u89TBmVz/AB/WoXXZSRWG7lZRc9bYwf3HsXM+c3zO88T186oqtS8m+joalDZFCnrP5vHRen8mRW1kk8jpZXOc93rOdvPN1DoWOiKo3niaiSSwgptq19ao9mPzeoSpvq0GdR1R+b1FV6DK931LJsFKsIH1DOr4lRYKV4YPqWewFNslfqS8Puc5e9FeJloiLeM4IiIAiIgC1eIYW2T0m+i/wPX81tEUdWlCrHdmso9Qm4PKIZNC5h2XNIPn1HivCl9RTtkGy5oI/wA3HgtNV4K4Zxm4/Ccj38VhXGzakNafzL3/AJNCldxlpLT6EbxzDhVU0tMf9pGWjodvYexwaexfO7mkEhws4Ehw4gg2I719MywuYbOaW9Y+K4jrOwsU1e6QZR1DeVaeAde0jR03s731f2FXcJyoS0zqvFflfQgv4byU14EURW+Ub+Id6coOcd4XTZMw6TqXrbPqacne1krR7Jcx5HY5ncOddRXCtWtcIsUh9IWk24nZ/jadn9Qau6XXG7Zp7t032pP7fY2rKWaWOwjGsRl6Rh/DUNPex4+K5yunaeNvQv6JYz+sD4rmSgoawOgsur82UVUul+lS4LYVFXaHOFTaHOF9wCqom0Ocd6bY5x3hMAIqbY6O8Jtjo7wvmGMFVOdWwynPTGPB6gvKDnHeFPNWtjHOQR9owb/yu+a8Vl+mytd6Un5fUmRUvoRaJg/I3yUROamcYsAOhT7IXzTfgc1e/t8z0iItwoFoL0ERAXF5duREB4XpiIgPa8SKiL4CzVeoepRrGvue98ERVv8Atrz+hIurZoivDt6ItUgMij9dv8Rn7gpYERY20enH+8yxS4Ee0/8A9Wzfy/8AuNXJgiKkzo9l9U/Fl+LcFkw7kRfUXpF+Pcr0G/sRF6I2ZkG9ZDd/aiKaJFMvlXAiL2U5GVHuW+0f9V/WPIoi+VerfkUqvRZtOPaFuURfbLjL+9pRrciiIivkJ//Z" alt="">
        <p>Our team consists of highly trained professionals who possess extensive experience and expertise in their respective fields.</p>
        <p>Each member of our staff undergoes rigorous training and continuous education to stay updated on the latest techniques and best practices.</p>
        <p>You can trust in the skills and knowledge of our trained professionals to provide you with top-quality service and personalized care tailored to your needs.</p>
    
        </div>
        <div class="box" >
        <h3>Sanitization and Hgiene </h3>
        <img src="https://static.vecteezy.com/system/resources/previews/019/468/305/non_2x/healthy-beauty-clean-skin-line-pictogram-dermatology-health-check-of-skin-icon-skincare-therapy-medical-treatment-of-skin-outline-icon-editable-stroke-isolated-illustration-vector.jpg" alt="">
        <p>Our facility strictly adheres to rigorous safety measures and sanitization protocols to ensure a clean and hygienic environment for all our clients.</p>
        <p>We employ industry-standard sanitation practices to disinfect equipment, tools, and surfaces regularly, maintaining a sterile environment.</p>
        <p>- Your safety is our top priority, and we go above and beyond to implement comprehensive sanitization procedures to protect your health and well-being.</p>
    
        </div>
        <div class="box" >
        <h3>Covid-19 Precautions</h3>
        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIWFRUXFxcVFhgYFRsYGBgYFxcXFxUVFxsYHyggGBolGxYVITEhJykrLi4uGB8zODMsNygtLisBCgoKDg0OGhAQGy8mICYvLTAvLy0tLS8tLS8tLS0tLS0vLS0tLS0tLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAIQBfQMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCAQj/xABCEAABAwEFBAcFBQYFBQAAAAABAAIDEQQFEiExBkFRYQcTInGBkaEyQnKxwRQjUmLwM0OCstHhFVOSwtIlNGNz8f/EABoBAAIDAQEAAAAAAAAAAAAAAAAEAgMFAQb/xAA2EQABAwEEBwcEAQQDAAAAAAABAAIDEQQSITEFQVFhcZGhEyKBscHR8BQyQuHxBhVSYjPC4v/aAAwDAQACEQMRAD8A7iiIhCIiIQiIiEIi8ucAKk0A3qtXtttZIagOMruDBUeZy8qqTWlxoAoSSMjFXmnFWdFzW1dJEh/ZwNA3VcXH0otJ3SDa/wDxj+E/Uq4WWT4UmdJWcazyK6ui5ZB0i2ke0yNw+FwPmHfRS9j6SochPEY+YcHeNDQ+VVx1mkaK0U47fA8gA47wf4V8RRl035Z7SKwTNfxANHDvacx5KTVCcRERCEREQhEREIRFr2u1RxNxSPaxo3uIA9VV7f0g2ZmUbXSniBhb5uz9FNsbn/aKqqSaOL73AK4IuazdJMp9izNHxOLvkAsLeke0b4Yz4Ef7lb9LJs6pY6Ss+08j7LqCLndl6Sj+8s472v8AoR9VYrs2xsk1B1nVuPuvGH109VB0EjcSFbHbIHmjXY76jzorEi+L6qkyiIiEIiIhCIiIQiKIvXaKz2fKSUYvwt7TvIaeKrFt6SGD9lA53Nzg30z+asZC9+QS8tqhiwe7HZr5K/IuXydJFo3RRjvxH6heo+kice1DGe4uH1Ks+ll2dVT/AHKz7TyK6cio9h6RoXZSxOZzaQ8fQ+itF2XvBaBWGVr+IB7Q72nMKt8T2fcExFaIpcGOB8+RxUgiIq1ciIiEIiIhCIiIQiIiEIiIhCKF2g2hisjKvOJ59lg9p3PkOa87UX8yyRYjm92UbeJ4n8o3rj9ttj5nukkcXPcakn5DgBwTMEF/E5eaz7bbex7jPu8v3sCkL92kntRON2Fm6NuQHfxPM+iiERaLWhooF5973PN5xqUREXVFYLVPhHM6KJll3uK27xPaA/KomTN1OdEnK6riNi9Fo+FrIg7WcTw2cls2e8CxwexzmOGYc00I7iF0rY/pSFWw23fkJqUp/wCwD+YeI3qguuduHIuxcfdr3KLms7mmjmkfJQkiI+4K6C1RTVDD6L9TRvDgCCCCKgjMEHQhZFxfov2skgcLNNU2d2THH9046Cp9wndu10qu0JVzS3NMBwJIByRERRUkVK2n23ZCTFBSSQZF3usP+48tPktHbvasgus0DqbpXjX4W/U+HFUOBla6fqlUwGMijM0uQp1IHqs2a1PklEFnpeNceAJoNWrPbljiM1ttss76yyOe7WtchyA0A7lh6ju9FlEQXtIWnTBDh9PlTWMPDEFXWbQoLT9R91cw7HxqKfNwWFsHEr11Q4LIizZNI2mQ1LyOGA6etTvWlFo2yxigYDxFT19MFidBwWBzaarcRzQdU5ZdMSxmkveHX0B8cd6TtehYpBWHuu6Hzp4YblvXFtPaLKQGuxR74yat/h3jw8l1C4NoIbWyrDRw9ph9pvPmOYXG5Y94SxWt8T2yRuLXtNQR8jxHJbMborXH2keHvv8AdZPaT2CTspMRhy2gnyK76igdl9oG2uLFk2RtBI3gdzh+UqeSjmlpoVsse17Q5uRREWneVvZBE6WQ0a0eJO4DiSVwYqRIAqUvG3xwRmSVwa0ep3ADeeS5ntDtvNOSyEmGPke07vI9nuHmojaC/JLXJjeaNHsM3NH1PEqLWlDZg3F2fksC1aQfJ3YzRvU+w+FfSviImVmoiIhCL1FI5rg5ri1w0INCO4heUAQhXrZvb1zSI7V2m6CQDtD4gPaHMZ966JDK17Q5rg5pFQQagjiFwyK7JXaMPjQfNW3Y61z2V2F5BhOra1LT+Jv1G9KTWWuLBjsWxY7bICGS4jbs47vLXu6WixxvBAINQRUHksiz1tIiIhCIiIQiIiEIsM8zWNc9xo1oLieAAqSsypfSVefV2dsLTnKc/hbQnzJb6qcbL7g1VTyiKMvOr4FQtob3dap3Su00Y38LRoO/eeZUaiLXAAFAvKOcXEudmUREXVFEREIUDa7bV57OnZ14FaeKhrTfVXO729rwWe8W9kd6q+lLgXV6ftarNKtYAwR4U/y/8qKs8uJodSlRVZURWrLdQnAYIupdHl+GaIwvNZIgKE6uZoD3jTyXLVJ7N3kbPaY5a5B1H/C7I+mfgqpo77CNepM2OfsZQdWR4fr3XcFW9tb8+zQUYaSyVazl+J3gPUhWRca23vLr7W8g9lnYZ3N9o+Lq+iQs8d9+OQW5b5zDFhmcB7+CgSVlsxz/AF+uCxICnrTD20TozrHXV1osCyzdhK2Qaj0yPSq2nNO5ecZ3tPgpHZ4h1oi+LMeBV0luCzuNTEB3Ej5FeN+meCWuwINCF7pkzHtD2GoOS54JOR8l9BXQWbP2Yfuge8uP1WxHdcLdImD+EfVdFldtUr65uiu+092MdCXhoDmCooKVbvB+ar9z3A+dpfiDG1oKipJGuXBVuhcHXRiuhwpVRFFpqWvGxOheWO1GYI0IOhUQt3QYIEgO0c8a+i85/UFL0XA/9fWqkLivV9mmbKzdk4fiB9pv63gLttltDZGNew1a4BzTyIqFwNdJ6MLyxRPs7jnGcTfhdqPB1f8AUtO1R1F/Yk9FzlrzGcjlx/YryV6XJdvr+M8xiYfu4iR8TtHO8NB48V0Da28vs9lkeDRxGFvxOyr4Cp8FxZQskeN8q7SlooBENeJ9AiIieWIiIrfsRs+JPv5W1YMo2nRxGpI3gad/coSPDG3iroYXTPDGqvWG555v2cRcONKN/wBRoFPWTYSZ37SRrBwFXH6D1XQQF4tEwY0uOg/QCSNqecGhbLNGQtFXknoOmPVUy37J2eJtC97nnTQDvIpkFhs1jZH7LQOep81tzzF7i46n9UWNaEbS1veNSlHhl6rG0RERTUVZNlrxz6lx5s+Zb9fNWdc3hlLXBw1BBHguhWWYPY140cAfNZtsjuuvDWtOxy3m3Tq8lmRESadRERCEREQhFybpJtWO2YN0bWt8T2j/ADDyXWVxPa99bbaD+enkAPomrIKvPBZmlX0hA2n3KiERForAW3ddgdM/A0gZVqdAMv6rDbLOY3uYaEtNCRoeYXiKRzTVpIPEGh9FmtFjlaMb2OAJ9og5k8TxXNalgW4DFZrobCZPvyQym7LPvHKq+XfYRNN1bXUb2iCdcI08dFv7M3VFOXda4gCgo3XOuar99y9TK5kTz2XGjgaGgOWm9UTztjBOtP2OxOtLmtwpiSddN/pxVktl1CzyloeHgtBB01rUHyWSK5pZ2HqwDTSppWmtFX7NebhGHyEvc46k50CsV3345kRLACCC4VqCOOiuinD47rD3qAkcfgULRYjBJflFGXnAEbQSOIrQ5qtPYQSCKEGhHMaqQuy72SNkc6UMLBUA78j6blkuq6n2p7jiDc6kni6pWpJd7xMYaAvDsOWnfXhTNBIOFUs1pFHEVGQWqisp2NmLC9rmuI3UpXiAVWiKZIa4OyUXxOZS8M12O7L0/wCnNnJzEJJ+JjSPm1cbB46roFgmP+Bv5Vb5yj/kqAqbO2hfx8k7bpC9sVf8Qef8IiImFnqS2a/7qH4voVbbjsFqZa7XJNJihkLepbirQCug9ygoOapF3vIkaWmjhWh4GhoVKXLetpLnh0xc0e9WorwHJZtuiLyXAjACu3NbejLU2KF14HOvQBdDUBc9gtTLbapJZMUD8PVNxVpTg33aDLnVVmxX9MZSHySVcSGtpRrR9TzWe+L0tLQ1zZDhBq6jqeHdqk/pHteIyRj8w8t5yWobey+Glp6e6vdohD2ljtHAg9xWrdUIYHxt9lriGjXUVPqSqPNfs5EWKUxhxq4gkZDQcqq0WW+YoWNxuJc7tGgJqDoa6aBUTw9i0OeRj6HblyVsNo7Z4a0EZn01bz0UNtufvgfyD5uVWUrtHeYnlxAUaAAK65V18yopaujYeziJP5GvhgB5VXn9LziW0UBwaKeOZ86eCKx7AWvq7bHweHMPiKj1aFXFIbPSYbVCeEjP5gE9IKtI3FIQOuytO8K49Ktq/YRfE8+FGt+blz5W/pPfW1NHCIernFVBV2cUjCvt5raH8uQCIi+xsLiGtBJJAAGpJyACuSakdnrodaZgwZNGb3cG/wBToF1mCJrGhrRRrQAANwGgUds5c4s0IZ757TzTUnd3DRSqzJ5b7sMgvS2Ky9gyp+45+3hr31RV2/bZidgGjdeZ/spa9LYI2V945N7+PgqqSrrHFU3z4fPnRRtstBcHj7fNy+sbU0Cxljm1xA94zH9lI2SGmq3sIIWdaNNlk5bGAWjDidZB2asQcq7E3DokOhBkJDj0G/zNCFACVvEL6HDipK03Wx2goeSi7Rdb26Z+hT9m0vZpcHG6f9sueXOiTn0ZPHi0Xhuz5Z8qr2rhsrPihw/hcR4HtD5lcyt96PYSwVB3kj5V+atnRZKSy0AmvaY7PmCP9qZtdDFySljmHb3Bvr4CqviIiyltoiIhCIiIQi4NtnK5lvtLSP3hOu5wDh6ELvK410uWDBbGy0yljB/iZ2XemDzU481wqqtto5nvW/aL2bI1rcEbS33mtLSRwdnQqBRMhzhrVDrNC6tWjHd8Kn7DaWtkY4gkNcCR3FWu9dpon2Z0TTUu0BaQRnqTplquaqz9HsJktrKkkNDnkajTCK+Lgh0hwJxoqvoo2tIZUV3181G/aCXBkdS9xDRQ8Vs3vckULRitPWS+81jatHEYq6rXvK3Vmme0NGKR5BDRWmI0od2S0SVmyzukNXfwtuy2KOztDY8Nu0neVliY57g1oqdGgfrxV5u7ZuZ8LS1ow0wjPXmqpcV+SWVxdG2MlwoS9tTTgDUUqrTY+kpwAD7M0gfgeW+hB+atstp7CpGZ2pfSVhda7rfxGOFMT+hktO1XdarD2sg12RI7Q5VqFp3Rb8M4kkNa1xHv3q1O27sU7cE0cjRUE1aHDI190/RSc5sdvge2FzXOa2ooMLmmmRoQDROx2trsCsSfRUsfeaTQaiNfFYv8YbHGT1jcJz1B8lzq1S4nudSmJxPmarFRfU4yMNWRNaDIBXUuh2Kzn/BHDiHO8pa/ILni7dZrsAsgs5/ysB7y3M+ZK4k5hBIORBIPeMiqbM+9e4/PJOaQiuCMf605fyviIiZWavTG1NM88stc8lOzvbDHUDJoyHoFAKQdeRMZbSrzQDga5V70paYnPLaYiuIrTx/epMwPGDDt/Sz3UzFWZxxPdl8I/CFivB/3resB6oUpQZFx3uUhZLJ1TQwg11NRqTqtQtM82EAlkZzA95/BKseDK54+0A45UGqlNeQHPanA4doTqFeI2U2HYvt5uLi2FtKvzJO5uhK2L6smEtYXUwxxsFRkKA0B8teal7Js658scr+yGVy/EDuPAKDvt5da7Q08wOWAAt+SrjDZLo1N7x41p0GPnrVrxJZ7PXEF2GsHWTvxoBwqoaWMtNCM15WwTWLP3XUHcRmPktda7XE1rqKxqUyRSOzceK1wDjI30cD9FHKzdHdj6y2tfTKNrnHyoPV3ouSGjCdyts7b0rQNo81t9JsB+1MIBOKMaciR/RVAwu/CfI/rcfJdF6ULKcMUwJFC5hIr7wq3TmCqAztGnae7QZ0/rlmq4HVjCYtzKWh2+nkvDrM8ascPA8SPm13kVYtg4I22pr5yG4QerxEAFxIaK8DnlzooFgaNRUj3RyoTUmtN+g3LZhcajSpLaCmVNM9STTEBirk46ZKb6lpCqho14dStPmwfyuxXvamRxl7hXc0DUncAqsL/AJA/E4DBoWjUc67yqlBeUpljEj3FhBa0OJwtOhw1AoKgeBAU04DeoQ2Vgb3sVpOtrpD3cKKR2khMgZMx2JlKd1TkfPI+Cio2uyq70W/d1oDKtOcbsnDv3jmtGadom6tvaBGJrwQWubypv3EclbH3R2Zy1cNnH9KErg49oMDr4+dDq34LM55OpW9YJOJ/W5RyzWUdrXTVJaUgY6yEVAu4jDYMtVK5caJnR8zm2gZm9gceu+meKmUXxmgX1eOXqVr2mxRyCj2gjmP1RSuy1hZEJMDQ2pbXwrr5rSU7dEdI68ST9PonrCXX6AmgxpXDlklbUG3bxArtoK881voiLXSKIiIQiIiEIqf0nXMbRYy9oq+E9YOJbSkg8s/4QrgvhC6DTFC/MSKydIOzkljtBMcTnWeQl0bm54Tq6IjdTdxHcVWQ8745B3xv+gTIxFVWXtBoSK8V6Vy2AHVxWy0fgiIaedCaeeFVKANJ7RIHcrld8LmXPIWNLjLLQ4WkkNa4A1puoz1Vcpo0q2Nt5wG9U8L6vi+rMW0vizNkZShZ4hxB9aj0WIBZTaD7zWHvaB/LQrqF9pEd7294DvkR8lbujyGLrpALQOtfG5jG4HCtaFxJORNBpXiqh1jDqwj4Xf8AIFX7o92ajcWWwSOIaXAMLaEPFWmrq9oUNRkFOOt4US9poIiHEiuCrV7Xc+zyuifqN/EHQqW2Gurr7Uyo7EdHv8D2R4up4ArPt/IJLWGs7Tg1raDMlxJoO/MK+bI3ELLAGmnWO7Uh57mjkBl5rblmpFU5leLs1kDrSWj7Wn+Bz6VU+uRdIF1dTanOA7Evbb8XvDzz/iXXVB7V3KLVAWCmNvajP5huPI6f/EnBJcfU5LWtsBmiIGYxHzeuMIvUsZa4tcCHAkEHUEagqRuG6DaHHOjG+0d/IDmtRzg0VK80xpebrc1GKburZm0SlrsOBtQauyrQ7hqrdYrqhi9hgB4nN3mVK2R2o8Um+1H8QtKGwCvfPL3/AIXor4Fle1YliyR3DRenil7RtUVXvTZeR0kssbmuL60aeyRWgOehy7la2tqshNAr7NebVw+YpS3MjlaGO48FyK2WCWI0kjc3vGXmMlrLqz8613qPtNywP1iaDxaMJ9Fqttf+QXn32A/iefz0XOV1Ho2urq4DM4dqU5fC3JvmanyVTsOyrpLZ1Ar1baOe7g07viJqPMrrUUYaA1ooAAABoAMgFG1Si6GjWmNG2Yh5kcMsBx1/N60NobuFos8kVKkirfibm31HquLPLjUEYACQW8DU9k7ydRn3VXfFzLpA2eLZftEY7Eh+8yya7iaaA6k8a8VCyyAG6VdpKzlwEjdWB4fpVFgqCdGtplXNx3D0ceG7evTHEuFaAkk1yFKA0A0oMsgOSwyEEgNyGgrrzJzoCfLJe4XdutfdNN24gDUfrinljA4j5r9EOYOlaA7twAcPrruPFeXWt5ABe4gaZ8NF6jeW4HZ5Ejw3geB9VjnZRxA03dxzBy5UXclE5fPBSjr+eW0wgO0xfWii4ZS1wc00I3rwi6uFxOa3p73lcKYqfCKeq17Lansdja4h3Hjy5hYUXHAOFDku33VDq4q+XHfzZRhPZeNR9W8RyU2CuUtcQQQaEZgjUK3XFtHWjJTR2gdpi7+BXmrfoox1khxbrGscNZHUcMvU6N0wJaRz4O1HUeOoHoeOdrijLiGjUmis0bA0ADQCijLms+WMjX2e7ipZRsUNxl45ny+Yp60yXnUGpERE6l0REQhEREIRERCFp3lYGTxujkbVrvMHc4HcQuP7RbPy2STC7NhPYeNHDgeDuS7Yta12VkrCyRoc06gj9UPNXQzGM7kna7G2cbHbfQ7vJcEVw2O2oZAwwy1DaktIFddQaLYv/o/eyr7McbderJ7Q+EnJ3jQ96pdogcxxa9rmOGocCD5FaFWTNoD7rCuS2R9SKeR8clYLdYrvtMzyyR1nJzrT7tx3nCfZ8KKu3ndDY34Y52yD8VCB3b18RUGwwkp5mm7W0UqPELSbZn6tzp+E18lmk69oBcJKHMYmktPMYhRZ1tRXpMxmBsrgzhXL+ypfo4fg4+P6om4v6heP+VgPCo86rSugsfNGyVjXMc9rXU7BAJoSC2mmufBXi/b4ZA2Oy2E0AqDg7Va+eJxJqoK5dmLRaSCyPC06yOaGjw3u8F0jZvZWGyjF7cu95GnJo90eq4yJlnNXG8fmeanNaprcAI2ljdZJ8hhzWhsbssYj9onzmdmAc8Fd54uPorkiKl7y81KYhhbE263L5iiIiirVS9ttlOvrNCPvQO03/MA+o9VF7Ix4bOKihxGtRQ1BpQ+S6QtC23e19SOy7juPf/VW9qblwpN9kHadq3PXvyx99qgV7gdRw8l6tFlez2h47vNYSuKGIKklie1YfteWQz310r9VoW2c1zJ9k07/AA071BzA4UKuZNcNQphoosVqdQU4rEy0Ea5j1XiaXEctBl47/opAUUHPrivK9wxOecLRU/LmVs2W7XvzPZHPXwCmrPZ2sFGjv4nvQTRdZETnkvNjsjY20Gp1O8rZRFBNAUwCLBarO2RrmPaHNcKOB3hZ0Qurje1ezD7I+oq6Fx7LuHJ3A89619mroNpkMYeGktJqa7iPPfx7l2aeFr2lj2hzXChBFQRzXLtquj+0xky2CUubr1LiA4fA4+0ORz5lPR2m8LrjQ7Vkv0YBJeZS7sJI5EavnCt2+Hq3ujqDhcRlnplrvXk1LWmjiRlXMig035akUoBkqvbbVaY3lkpex7ci17cLh4EaJZbymDgeuLANXbx3AUJP6qE4l/7ZJXMdfZdCds3MGfacH3WHH45ClOGKprphFVAuYdSD4hWiTpTjNjw9VIHmsOLEMVAwfe6UxZ1px371zO03jNir1xfXMO499cweR9VVE55reFFbNoytOzPGqud1XRLaHFkbCTSoO7LUE6afRYbyu98Lyx7SC3I13neRxFeChNmtrZ7JK17CCSQ1+IZYaioAFPP9H79utt4zF0bHyTOIxdWOxyJJyZlTfT6z7wcSclE6MNzA97pTlXot9XLYrZEykTztpGM2tOsh3E/l+fctzY7o8dERLbZOtfqIh+zafzGnbPLTvXRUrNafxZz9lZZtGXXXpSDTV71+bURESK10REQhEREIRERCEREQhEREIRatssUcowyxtePzNB8q6LaRCCK4FVa1bB2N+jHM+F5+TqhaJ6N4N00noruitE0g/Ipc2SA/gOXsqbD0d2Ye0+V3LEAPQV9VMXfszZIaFkDaj3ndo+bq08FNIuGV5zK6yzQsNWtHJERFWr0REQhEREIRERCF8K05rtjd7tO7L00W6iFwgHNRLrmG558RX+iwSXAT+83Fvs8fFTqLtSodkzYottzt3ucfILcgsjGey0V46nzK2ERVSDGjIIiIuKSIiIQiIiEIiIhC0L0umC0NwzwslH52g07jqPBU68eiWwSZxmWE/lfib5SAn1XQEU2yPb9pXKLk8vQy3RltcBWvahBPo8cF6h6GI/ftjz8MTW/MuXVkU/qJdqLoVHuzosu+Khcx8xH+a+o/0sDWnxBVwsdjjiaGRMbG0aNa0NHkFsIq3Pc77jVdoiIiihEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhf/9k=" alt="">
        <p>We follow all government guidelines and regulations regarding COVID-19 safety protocols, including social distancing, mask-wearing, and capacity limits.</p>
        <p>Our facility is regularly sanitized, and additional measures such as temperature checks and health screenings are conducted to mitigate the risk of transmission.</p>
        <p>- Rest assured that we are committed to providing a safe and comfortable environment for everyone, and your health and safety are our utmost priority.</p>
    
    
        </div>
      </div>
    </section>`
    <!--safety measures ends-->

    <!-- about starts  ends -->
    <section class="about" id="about">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-md-6 content">
                
              <span>About Us</span>
              
              <div class="about-container">

                <img src="https://revivalbeautyspa.com.au/wp-content/uploads/2018/06/sot1.jpg" alt="Logo" class="float-left">
        
                  <div class="about-box float-right">
              
                <h2>true appreciators of your beauty and health</h2>
                
                <p>Welcome to Mobile beauty and therapy, where beauty meets well-being, and relaxation is redefined.</p><br>
                <p>At Mobile Beauty and Therapy, we believe in the transformative power of self-care and the profound impact it can have on your life.</p><br>
                <p>Our team of dedicated professionals is passionate about curating experiences that go beyond traditional beauty services.</p><br> 
                <p>We understand that true beauty radiates from within, and our mission is to enhance both your inner and outer glow.</p><br>
                <p>Our plaftform also helps you our client save time and effort, enhance relaxation and privacy and personalization </p><br>

                

              </div>
          </div> 
      </div>  

    </section>
    <!-- about section ends-->

    <!-- review section starts -->
    <section class="review" id="review">
      <h1 class="heading">Satisfied Clients</h1>
      <div class=" box-container container">
          <div class="box" >
          <h3>HASEEEM MALIK</h3>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZ5Kszh96f9jjeLau2awy3iHclNar-ue3hdw&usqp=CAU" alt="">
            <p>Superb! great service, high maintenance of hygiene and skilled personels.</p>
            <div class="stars">
              <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
            </div>
            <a href="review.php" class="link-btn">Make Review</a>
          </div>

          <div class="box">
          <h3>KYLIE MUSA</h3>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS27I4w4TyKeVzo5XpPnyVYY2dqdIgUjosL6w&usqp=CAU" alt="">
            <p>Never felt in a relaxed mode till met mobile beauty and therapy. Comfortability at place.</p>
          
            <div class="stars">
              <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
                <i class="fas fa-star"><label>☆</label></i>
            </div>
            <a href="review.php" class="link-btn">Make Review</a>
        </div>

        <div class="box" >
            <h3>CATHELENE MCAILER</h3>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSv7UTnnr5RlC-iwtRhAJfmx1rvowQzxImVlg&usqp=CAU" alt="">
            <p>Excellent services! Perfect profesonalism and talent. highly recommend it</p>
            <div class="stars">
              <i class="fas fa-star"><label>☆</label></i>
              <i class="fas fa-star"><label>☆</label></i>
              <i class="fas fa-star"><label>☆</label></i>
              <i class="fas fa-star"><label>☆</label></i>
              <i class="fas fa-star"><label>☆</label></i>
            </div>
            <a href="review.php"class="link-btn">Make Review</a>
          </div>

        

    
        </div>

    </section>
    <!--footer section starts-->
    <section class="contact" id="contact">
     <h1 class="heading">CONTACT US</h1>
      <div class="box-container container">
        
        <div class="box">
          <i class="fas fa-phone"><ion-icon name="call-outline"></ion-icon></i> 
          <h3>phone number</h3>
          <p>+254 713 613 462</p>
          <p>+254 740 333 333</p>
        </div>

        <div class="box">
          <i class="fas fa-envelope"><ion-icon name="mail-outline"></ion-icon></i> 
          <h3>email adress</h3>
          <p>mobilebeautyandtherapy@gmail.com</p>
          <P>mobilebeautytherapy@yahoo.com</P>
        </div>

        <div class="box">
          <i class="fas fa-phone"><ion-icon name="logo-whatsapp"></ion-icon></i>
          <h3>whatsapp</h3>
          <p>+254 713 613 462</p>
          <p>+254 740 333 333</p>
        </div>

      </div>
     
    

    </section>

    <section class="footer" id="footer">
      <div class="credit">&copy; copyright @ <?php echo date('d/m/y')?> by <span>mobilebeautyandtherapy</span></div>
    </section>

    <!--footer section ends -->      
        






  <script src="js/script.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
 </body>

</html>