<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing - Mobile Beauty & Therapy</title>
    <style>
        :root{
            --blue:#00b8b8;
            --black:#333;
            --white:#ffff;
            --light-color:lightgrey;
            --light-bg:#eeee;
            --border:.2rem solid rgba(0,0,0,.1);
            --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);

        }

        *{
            font-family: Arial, Helvetica, sans-serif;
            margin:0;
            padding:0;
            box-sizing: border-box;
            outline:none;
            border:none;
            text-decoration: none;
            text-transform: capitalize;
        }
        *::-webkit-scrollbar{
            height: .5rem;
            width: 1rem;
        }
        *::-webkit-scrollbar-track{
            background-color: transparent;
        }
        *::-webkit-scrollbar-thumb{
            background-color: aqua;
            border-radius: 5px;
        }

        html{
            font-size:62.5%;
            overflow-x: hidden;
            scroll-behavior: smooth;
            scroll-padding-top: 6.5rem;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            align-items: center;
        }

        header {
            background-color:var(--blue);
            color: #fff;
            text-align: center;
            padding: 20px 0;
    
            
        }
        .prices{
            width:100%;
            padding:30px;
            display:grid;
            grid-template-columns: 45fr 2fr;
            gap:60px;
          /* margin-top: 10px;*/

        }
        .prices table{
            width:100%;
            border-collapse: collapse;
            margin-top: 10px;

        }
        .prices table thead td{
            font-weight: 800;
            font-size: 2rem;
        }
        .prices table tr{
            color:#333;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        
        }

        
        .prices table tbody tr:hover{
            background-color: var(--light-bg);
            color:var(--white);
        }

        .prices table tr td{
            padding: 20px;
            font-size: 1.4rem;
            color:#333;
        }

        .prices table tr td a{
            padding: 20px;
            font-size: 1.4rem;
            color:var(--blue);
        }
        .prices table tr td:last-child{
            text-align: center;
        }
        .prices table tr td:first-child{
            text-align: center;
        }
        .prices table tr td:nth-child(2){
            text-align: center;
            color: #00b8b8;
        }
        .prices table tr td:nth-child(3){
            text-align: center;
        }
        .prices table tr td:nth-child(4){
            text-align: center;
        }

        section {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            padding: 20px;
            background-color: var(--light-color);
        }
        .footer .credit{
            text-align: center;
            border-top:var(--border);
            padding-top:2rem;
            margin-top:2rem;
            font-size: 2rem;
            color:black;
            padding-bottom:2rem;
        }

       

        
    </style>

    
</head>
<body>

    <header>
        <div class="container">
            <h1>Mobile Beauty & Therapy<span> Pricing</span></h1>
        </div>
    </header>

    <div class="prices">
      <table>
        <thead>
          <tr>
            <td>service name</td>
            <td>service description</td>
            <td>service varieties</td>
            <td>prices</td>
            <td>Make appointment</td>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>HAIR STYLING</td>
            <td> Our hair styling service offers a wide range of options to cater to your unique preferences and needs. Whether you're looking for a trendy haircut, a classic style, or something bold and creative, our experienced stylists are here to make your vision a reality.</td>
            <td>hair cuts, coloring,treatments,styling</td>
            <td>$25-$100</td>
            <td><a href="make appointment.php">book</a></td>


          </tr>
        </tbody>
        <tbody>
          <tr>
            <td>Massage Therapy</td>
            <td>Indulge in the ultimate relaxation with our massage therapy services. Whether you're seeking relief from muscle tension, stress, or simply want to treat yourself to a soothing experience, our licensed massage therapists are dedicated to promoting your overall well-being and relaxation.</td>
            <td>Swedish Massage, deep tissue massage, sports massage, hot stone massage</td>
            <td>$100-$250</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Tanning Studio</td>
            <td>Achieve a sun-kissed glow all year round with our tanning studio services. Our state-of-the-art tanning beds and booths offer a safe and effective way to achieve a natural-looking tan without the harmful effects of UV exposure.</td>
            <td>UV tanning, Spray Tanning, Skin care</td>
            <td>$30-$120</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>psychological therapy</td>
            <td>Take control of your mental health and well-being with our psychological therapy services. Our licensed therapists provide compassionate and evidence-based treatments to help you navigate life's challenges, improve coping skills, and achieve emotional balance.</td>
            <td>Cognitive-Behavioral Therapy, individual therapy,couple therapy, group therapy,Dialectical Behavior Therapy</td>
            <td>$200-$300</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Orthopedic therapy</td>
            <td>Recover from injuries, surgeries, or chronic conditions with our orthopedic therapy services. Our skilled therapists specialize in orthopedic rehabilitation to help you restore mobility, reduce pain, and regain function.</td>
            <td>Physical therapy, sports rehabilitation, manual therapy, Occupational therapy</td>
            <td>$150-$300</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>tattoo and piericing</td>
            <td>Express your individuality and creativity with our tattoo and piercing services. Our talented artists and piercers offer a wide range of designs and styles to help you bring your vision to life.</td>
            <td>Tattoo, piercing,custom designs,aftercare products </td>
            <td>$20-$100</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Beauty salon</td>
            <td>Indulge in a full-service beauty experience at our salon. From hair care and skincare to makeup and nail services, we offer everything you need to look and feel your best from head to toe.</td>
            <td>hair services, make up services,nail services, skin services</td>
            <td>$100-$200</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Botox</td>
            <td>Refresh and rejuvenate your appearance with Botox injections. Our licensed medical professionals offer safe and effective treatments to reduce the appearance of fine lines and wrinkles, giving you a more youthful and refreshed look.</td>
            <td>Botox injections, Consultations, Follow-up care, Safety</td>
            <td>$200-$450</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>facial surgery</td>
            <td>Transform your appearance and boost your confidence with facial surgery. Our board-certified plastic surgeons specialize in a variety of facial procedures to address aging, asymmetry, and other aesthetic concerns.</td>
            <td>Brow Lift, Eyelid Surgery,Rhinoplasty, Facelift</td>
            <td>$100-$400</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Manicure and Pedicure</td>
            <td>Treat yourself to luxurious manicures and pedicures at our salon. Our skilled nail technicians offer a range of services to pamper your hands and feet and leave them looking and feeling beautiful.</td>
            <td>Manicures, Pedicures, Gel Nails, Nail Arts</td>
            <td>$100-$300</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>


        <tbody>
          <tr>
            <td>Waxing Salon</td>
            <td>Experience smooth and silky skin with our waxing services. Our skilled estheticians provide gentle and effective hair removal treatments to help you achieve long-lasting results and silky-smooth skin.</td>
            <td>Body waxing, Brazillian Waxing, Aftercare, Facial waxing</td>
            <td>$30-$90</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>gym and fitness</td>
            <td>Achieve your fitness goals and lead a healthier lifestyle with our gym and fitness center. Our state-of-the-art facilities, experienced trainers, and diverse range of classes are designed to help you reach your full potential.</td>
            <td>Strength Training,Cardio,Group classes,Personal Training</td>
            <td>$30-$70</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Weight Loss</td>
            <td>Take control of your weight and improve your health with our weight loss programs. Our team of experts provides comprehensive support, guidance, and resources to help you achieve sustainable weight loss and long-term success.</td>
            <td>Nutritional Counseling,Fitness Coaching,Behavior Modification,Medical support</td>
            <td>$40-$100</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Personal Trainer</td>
            <td>Maximize your fitness potential with the guidance of a certified personal trainer. Our trainers provide personalized workouts, coaching, and support to help you achieve your fitness goals safely and effectively.</td>
            <td>Progress Tracking,Form Correction,Custom Workouts,Initial Assessment</td>
            <td>$30-$60</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Make UP</td>
            <td>Enhance your natural beauty and boost your confidence with our professional makeup services. Whether you're preparing for a special occasion, photo shoot, or simply want to refresh your look, our talented makeup artists are here to help you look and feel your best.</td>
            <td>Special Occasion Makeup,  Editorial Makeup, Everyday Makeup, Makeup Lessons</td>
            <td>$40-$100</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td>Skincare Treatments</td>
            <td>Achieve radiant and youthful-looking skin with our range of skincare treatments. Whether you're concerned about acne, aging, or maintaining a healthy complexion, our skilled estheticians are dedicated to providing personalized solutions to help you achieve your skincare goals.</td>
            <td>Microdermabrasion, Chemical Peels,Acne Treatments,Facials</td>
            <td>$50-$100</td>
            <td><a href="make appointment.php">book</a></td>
          </tr>
        </tbody>

        
    </div>

    

   
</body>
</html>
    