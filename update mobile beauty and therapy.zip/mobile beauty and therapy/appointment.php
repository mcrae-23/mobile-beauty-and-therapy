<?php
// Start session to maintain user login state
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include "db_config.php"; // Assuming this file contains code to connect to your database

// Retrieve appointments for the logged-in user
$username = $_SESSION['username'];
$sql = "SELECT * FROM appointments WHERE username = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$appointments = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

        :root{
            --blue:#00b8b8;
            --black:#333;
            --white:#ffff;
            --light-color:lightgrey;
            --light-bg:#eeee;
            --border:.2rem solid rgba(0,0,0,.1);
            --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);

        }

        *{
            font-family: Arial, Helvetica, sans-serif;
            margin:0;
            padding:0;
            box-sizing: border-box;
            outline:none;
            border:none;
            text-decoration: none;
            text-transform: capitalize;
        }
        *::-webkit-scrollbar{
            height: .5rem;
            width: 1rem;
        }
        *::-webkit-scrollbar-track{
            background-color: transparent;
        }
        *::-webkit-scrollbar-thumb{
            background-color: aqua;
            border-radius: 5px;
        }

        html{
            font-size:62.5%;
            overflow-x: hidden;
            scroll-behavior: smooth;
            scroll-padding-top: 6.5rem;
        }
        section{
            padding:7rem 2rem;
        }
        header {
            background-color:var(--blue);
            color: #fff;
            padding: 10px;
           text-align: center;
        }

        .container {
            margin: 20px;
        }

        h1, h2 {
            margin-top: 0;
            font-size: 1.6rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: var(--blue);
            color: #fff;
        }

        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            margin-bottom: 10px;
        }

        nav ul {
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 1.5rem;
        }

        nav ul li a:hover {
            color: #ddd;
        }


    </style>
    <title>Your Appointments</title>
</head>
<body>
    <header>
        <h1>Your Appointments</h1>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <section class="container">
        <h2>Appointments for <?php echo $username; ?></h2>
        <?php if (!empty($appointments)): ?>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Location</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Service</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?php echo $appointment['name']; ?></td>
                        <td><?php echo $appointment['address']; ?></td>
                        <td><?php echo $appointment['location']; ?></td>
                        <td><?php echo $appointment['appointment_date']; ?></td>
                        <td><?php echo $appointment['appointment_time']; ?></td>
                        <td><?php echo $appointment['service_type']; ?></td>
                        <td><?php echo $appointment['status']; ?></td>
                        <td>
                        <?php if ($appointment['status'] === 'Pending'): ?>
                            <a href="decline appointment.php?action=<?php echo $appointment['action']; ?>">Decline</a>
                        <?php endif; ?>
                    </td>

                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>No appointments found.</p>
        <?php endif; ?>
    </section>
</body>
</html>
