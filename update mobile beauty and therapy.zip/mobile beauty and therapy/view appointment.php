<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('db_config.php');

// Fetch appointments based on user_id
$user_id = $_SESSION['user_id'];
$selectsql = "SELECT * FROM appointments WHERE user_id = $user_id";
$result = $conn->query($selectsql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Appointments</title>
    <style>
        /* Add some basic CSS styles for better presentation */
        body {
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Your Appointments</h1>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Appointment Date</th>
                <th>Appointment Time</th>
                <th>Service Type</th>
                <th>Payment Method</th>
                <th>Amount</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row["appointment_date"]; ?></td>
                    <td><?php echo $row["appointment_time"]; ?></td>
                    <td><?php echo $row["service_type"]; ?></td>
                    <td><?php echo $row["payment_method"]; ?></td>
                    <td><?php echo $row["amount"]; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No appointments found.</p>
    <?php endif; ?>

    <p><a href="logout.php">Logout</a></p>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>
