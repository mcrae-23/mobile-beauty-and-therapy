<?php
session_start();
require_once 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = mysqli_real_escape_string($conn, $_POST["full_name"]);
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    $confirm_password = mysqli_real_escape_string($conn, $_POST["confirm_password"]);

    // Additional validation can be added here

    // Hash the password before storing it in the database
    if ($password != $confirm_password) {
        echo "Password do not match";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Use prepared statement to insert data into the database
        $stmt = $conn->prepare("INSERT INTO users (full_name, username, phone_number, email, password) VALUES (?, ?, ?, ?, ?)");

        // Check if the prepare statement succeeded
        if ($stmt === false) {
            echo "Error in preparing statement: " . $conn->error;
        } else {
            // Bind parameters
            $stmt->bind_param("sssss", $full_name, $username, $phone, $email, $hashedPassword);

            // Execute the query
            if ($stmt->execute()) {
                echo "Registration successful!";
                
                // You can redirect to the login page or any other page after successful registration
                header("Location: login.php");
                exit();
            } else {
                echo "Error in execution: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        }
    }

    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration - Mobile Beauty & Therapy</title>
    <link rel="stylesheet" href="logins.css">
    <style>
        /* Your styles go here */
    </style>
</head>
<body>
    <header>
        <h2>REGISTRATION</h2>
        <nav>
            <ul>
                <a href="home.php">Home</a>
                <a href="login.php">Login</a>
            </ul>
        </nav>
    </header>
    

    <!-- Your registration form goes here -->
    <section class="container">

        <form method="post" action="">
            <label for="full_name">full_name:</label>
            <input type="text" id="full_name" name="full_name" required>

            <label for="username">username:</label>
            <input type="text" id="username" name="username" required>



            <label for="phone">phone:</label>
            <input type="phone" id="phone" name="phone" required>

            <label for="email">email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password"> Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">confirm Password:</label>
            <input type="confirm_password" id="confirm_password" name="confirm_password" required>

            <!-- Add additional fields as needed -->

            <button type="submit">Register</button>

            <?php
            if (isset($error)) {
                echo '<p style="color: black;">' . $error . '</p>';
            }
           ?>
        </form>
    </section>

    <!-- Add a link to the login page if needed -->

</body>
</html>
