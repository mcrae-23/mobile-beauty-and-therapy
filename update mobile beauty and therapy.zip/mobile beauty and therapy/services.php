<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="styles.css">
    <style>
            :root{
                --blue:#00b8b8;
                --black:#333;
                --white:#ffff;
                --light-color:lightgrey;
                --light-bg:#eeee;
                --border:.2rem solid rgba(0,0,0,.1);
                --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);

            }

            *{
                font-family: Arial, Helvetica, sans-serif;
                margin:0;
                padding:0;
                box-sizing: border-box;
                outline:none;
                border:none;
                text-decoration: none;
                text-transform: capitalize;
            }
            *::-webkit-scrollbar{
                height: .5rem;
                width: 1rem;
            }
            *::-webkit-scrollbar-track{
                background-color: transparent;
            }
            *::-webkit-scrollbar-thumb{
                background-color: aqua;
                border-radius: 5px;
            }

            html{
                font-size:62.5%;
                overflow-x: hidden;
                scroll-behavior: smooth;
                scroll-padding-top: 6.5rem;
            }
            .image-container {
                width: 100%;
                height: 600px; /* Adjust height as needed */
                background: url('images/home-image.jpg') center/cover no-repeat; /* Add background image */
                display: flex;

                justify-content: space-around;
                padding: 90px;
            }

            .header{

            display:inline-block;
            padding: 2rem;
            border-bottom: var(--border);
            
            }



            .header .logo{
            font-size: 2rem;
            color:var(--black);
            font-weight: bold;


            }
            .header .logo span{
            color:var(--blue);

            }
            .header a{
            text-decoration: none; /* Removes underline by default */
            color:var(--black); /* Set the link color */
            font-weight: bold; /* Optionally set the font weight */
            padding: 10px 15px; /* Add padding for better styling */
            display: inline-block; /* Ensures padding and border are respected */
          
            font-size: 2rem;
            }


            .header a:hover{
            color:var(--blue);
            }


            /* Service section styles */
            .service {
                background-color: var(--white);
                padding: 20px;
                margin-bottom: 20px;
            }
            .service:nth-child(even) .service-container {
                flex-direction: row-reverse; /* Reverse the order of flex items on even service sections */
            }


            .service span {
                color: var(--blue);
                font-size: 2rem;
            }

            .service-container {
                display: flex;
                justify-content: space-between;
            }
            .service img {
                max-width: 600px; /* Set a maximum width */
                height: 300px; /* Set a medium height */
                width: auto; /* Let the width adjust automatically to maintain aspect ratio */
                margin-bottom: 20px;
            }


           
            .service-box {
                width: 50%; /* Adjust width as needed */
            }

            .service p {
                font-size: 1.4rem;
                color: var(--black);
            }

            .service strong {
                font-weight: bold;
                font-size: 1.5rem;
            }

            .service ul {
                list-style-type: disc;
                margin-left: 20px;
            }

            .service ul li {
                margin-bottom: 5px;
                font-size: 1.3rem;
            }
    </style>
</head>
<body>
<div class="image-container">
        <div class="header align-items-center">
            <a href="services.php" class="logo">OUR SERVICES</a>
            
                <a href="home.php">HOME</a>
                <a href="register.php">REGISTER</a>
                <a href="login.php">LOGIN</a>
                <a href="pricing.php">PRICING</a>
                <a href="make appointment.php">MAKE APPOINTMENT</a>
            
        </div>

</div>


    <div class="service" id="service">
        <div class="container">
            <span>Hair Styling</span>
            <div class="service-container">
                <img src="images\hair-styling.jfif" alt=" ">

            
                    <div class="service-box">
                        <p><strong>Description:</strong> Our hair styling service offers a wide range of options to cater to your unique preferences and needs. Whether you're looking for a trendy haircut, a classic style, or something bold and creative, our experienced stylists are here to make your vision a reality.</p>
                        <p><strong>Benefits:</strong></p>
                        <ul>
                            <li>Personalized consultation to understand your hair goals and preferences.</li>
                            <li>Professional and skilled stylists with expertise in various hair types and styles.</li>
                            <li>High-quality products and tools to achieve stunning results while maintaining the health of your hair.</li>
                            <li>Relaxing salon environment where you can unwind and enjoy a pampering experience.</li>
                        </ul>
                        <p><strong>Features:</strong></p>
                        <ul>
                            <li>Haircuts: Precision cuts tailored to your face shape and hair texture.</li>
                            <li>Styling: Blowouts, curls, straightening, and updos for any occasion.</li>
                            <li>Coloring: Full color, highlights, balayage, and color correction services.</li>
                            <li>Treatments: Deep conditioning treatments to nourish and repair damaged hair.</li>
                        </ul>

                    </div>
            </div>
        </div>

       
        
       
       
    </div>
    <div class="service" id="service">
         <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 content">
                <span>Massage Therapy</span>
                    <div class="service-container">
                    <img src="images\massage.jpg" alt=" ">
                    <div class="service-box">
                            <p><strong>Description:</strong> Indulge in the ultimate relaxation with our massage therapy services. Whether you're seeking relief from muscle tension, stress, or simply want to treat yourself to a soothing experience, our licensed massage therapists are dedicated to promoting your overall well-being and relaxation.</p>
                                <p><strong>Benefits:</strong></p>
                                <ul>
                                    <li>Alleviate muscle tension and soreness for improved flexibility and mobility.</li>
                                    <li>Reduce stress and anxiety levels, promoting a sense of calm and relaxation.</li>
                                    <li>Improve circulation and lymphatic drainage for enhanced detoxification and healing.</li>
                                    <li>Customize your massage experience with a variety of techniques and pressure levels to suit your needs.</li>
                                </ul>
                                <p><strong>Features:</strong></p>
                                <ul>
                                    <li>Swedish Massage: Gentle strokes and kneading to promote relaxation and stress relief.</li>
                                    <li>Deep Tissue Massage: Targeted pressure to release chronic muscle tension and knots.</li>
                                    <li>Sports Massage: Techniques to enhance athletic performance, prevent injuries, and aid in recovery.</li>
                                    <li>Hot Stone Massage: Heated stones applied to key points to melt away tension and promote deep relaxation.</li>
                                </ul>

                    </div>

                    </div>

                </div>

            </div>
        </div>
    </div>
    <div class="service" id="service">
        <div class="container">
            <span>Tanning studio</span>
            <div class="service-container">

                <img src="images\tanning image.jpg" alt="">

            
                    <div class="service-box">
                        <p><strong>Descrption:</strong>Achieve a sun-kissed glow all year round with our tanning studio services. Our state-of-the-art tanning beds and booths offer a safe and effective way to achieve a natural-looking tan without the harmful effects of UV exposure.</p>
                        <p><strong>Benefits:</strong></p>
                        <ul>
                            <li>Customize your tan with different levels of intensity to suit your preferences.</li>
                            <li>Enhance your skin tone and complexion for a healthy, radiant appearance.</li>
                            <li>Enjoy a relaxing and rejuvenating experience in our modern and clean studio environment.</li>
                            <li>Extend the life of your tan with our selection of high-quality skincare products.</li>
                        </ul>

                        <p><strong>Features:</strong></p>
                        <ul>
                            <li>UV Tanning: Traditional tanning beds and booths for a natural-looking tan.</li>
                            <li>Spray Tanning: Sunless tanning solution applied evenly for a streak-free tan.</li>
                            <li>Skin Care: Moisturizers, tan extenders, and aftercare products to nourish and protect your skin.</li>
                            
                        </ul>
                    </div>
            </div>
        </div>

    </div>

    <div class="service" id="service">
        <div class="container">
            <span>Psychological Therapy</span>
            <div class="service-container">
                <img src="images\psychology image.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Take control of your mental health and well-being with our psychological therapy services. Our licensed therapists provide compassionate and evidence-based treatments to help you navigate life's challenges, improve coping skills, and achieve emotional balance.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Gain insight into your thoughts, feelings, and behaviors to foster self-awareness and personal growth.</li>
                        <li>Develop effective coping strategies to manage stress, anxiety, depression, and other mental health concerns.</li>
                        <li>Build resilience and improve your overall quality of life through therapy and counseling.</li>
                        <li>Receive individualized support and guidance in a safe and confidential environment.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Individual Therapy: One-on-one sessions tailored to your specific needs and goals.</li>
                        <li>Couples Therapy: Relationship counseling to enhance communication, resolve conflicts, and strengthen connections.</li>
                        <li>Group Therapy: Supportive group settings for shared experiences and peer support.</li>
                        <li>Cognitive-Behavioral Therapy (CBT), Dialectical Behavior Therapy (DBT), and other evidence-based modalities.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
    <div class="service" id="service">
        <div class="container">
            <span>Orthopedic Therapy</span>
            <div class="service-container">
                <img src="images\orthopedic.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Recover from injuries, surgeries, or chronic conditions with our orthopedic therapy services. Our skilled therapists specialize in orthopedic rehabilitation to help you restore mobility, reduce pain, and regain function.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Receive personalized treatment plans based on your specific orthopedic needs and goals.</li>
                        <li>Improve joint mobility, flexibility, and strength through targeted exercises and techniques.</li>
                        <li>Accelerate recovery and prevent future injuries with comprehensive rehabilitation programs.</li>
                        <li>Work with experienced therapists who understand the unique challenges of orthopedic conditions.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Physical Therapy: Hands-on treatments, exercises, and modalities to address musculoskeletal issues.</li>
                        <li> Occupational Therapy: Functional training to improve daily activities and restore independence.</li>
                        <li>Manual Therapy: Soft tissue mobilization, joint manipulation, and other manual techniques.</li>
                        <li>Sports Rehabilitation: Return-to-play programs for athletes recovering from sports injuries.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Tattoo and Piercing</span>
            <div class="service-container">
                <img src="images\tattoo and piercing-image.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Express your individuality and creativity with our tattoo and piercing services. Our talented artists and piercers offer a wide range of designs and styles to help you bring your vision to life.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Choose from a diverse selection of tattoo designs or collaborate with our artists to create a custom piece.</li>
                        <li>Trust our skilled piercers to provide safe and hygienic piercing services using high-quality materials.</li>
                        <li>Enjoy a comfortable and welcoming studio environment where your safety and satisfaction are our top priorities.</li>
                        <li>Showcase your personality and style with unique body art that reflects your identity and values.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Tattooing: Traditional, realism, tribal, blackwork, and other tattoo styles.</li>
                        <li>Piercing: Earlobe, cartilage, nose, lip, eyebrow, and body piercings.</li>
                        <li>Custom Designs: Consultations and design sessions to bring your ideas to life.</li>
                        <li>Aftercare Products: Tattoo balms, piercing cleansers, and healing solutions to promote proper healing.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Beauty Salon</span>
            <div class="service-container">
                <img src="images\beauty salon.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Indulge in a full-service beauty experience at our salon. From hair care and skincare to makeup and nail services, we offer everything you need to look and feel your best from head to toe.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Treat yourself to a day of pampering and relaxation in our stylish and modern salon environment.</li>
                        <li>Receive personalized consultations and recommendations from our team of skilled professionals.</li>
                        <li>Enhance your natural beauty with expertly executed haircuts, colors, facials, and makeup applications.</li>
                        <li>Enjoy top-of-the-line products and techniques that deliver stunning results while nourishing and protecting your skin and hair.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Hair Services: Cutting, styling, coloring, highlights, extensions, and treatments.</li>
                        <li>Skin Services: Facials, peels, microdermabrasion, dermaplaning, and waxing.</li>
                        <li>Makeup Services: Bridal, special occasion, and everyday makeup application.</li>
                        <li>Nail Services: Manicures, pedicures, gel polish, nail art, and nail extensions.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Botox</span>
            <div class="service-container">
                <img src="images\botox-image.jfif" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Refresh and rejuvenate your appearance with Botox injections. Our licensed medical professionals offer safe and effective treatments to reduce the appearance of fine lines and wrinkles, giving you a more youthful and refreshed look.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Smooth away wrinkles and fine lines for a more youthful and rejuvenated appearance.</li>
                        <li>Enhance your natural beauty with subtle and natural-looking results.</li>
                        <li>Enjoy quick and convenient treatments with minimal downtime and discomfort.</li>
                        <li>Achieve long-lasting results that improve over time with regular maintenance treatments.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Botox Injections: Targeted injections to relax facial muscles and smooth wrinkles.</li>
                        <li>Consultations: Personalized assessments and treatment plans tailored to your goals.</li>
                        <li>Follow-up Care: Guidance on post-treatment care and maintenance to optimize results.</li>
                        <li>Safety: FDA-approved treatments performed by experienced and qualified medical professionals.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Facial Surgery</span>
            <div class="service-container">
                <img src="images\facial--surgery.jfif" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Transform your appearance and boost your confidence with facial surgery. Our board-certified plastic surgeons specialize in a variety of facial procedures to address aging, asymmetry, and other aesthetic concerns.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Address specific concerns such as sagging skin, wrinkles, volume loss, or asymmetry.</li>
                        <li>Achieve natural-looking results that enhance your facial features and overall harmony.</li>
                        <li>Benefit from the latest surgical techniques and advancements in facial plastic surgery.</li>
                        <li>Receive personalized care and support throughout your surgical journey from consultation to recovery.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Facelift: Tighten loose skin, smooth wrinkles, and restore youthful contours.</li>
                        <li>Rhinoplasty: Reshape and refine the nose for improved aesthetics and function.</li>
                        <li>Eyelid Surgery: Correct drooping eyelids, bags under the eyes, and other eyelid concerns.</li>
                        <li>Brow Lift: Lift and rejuvenate the brow area for a more alert and youthful appearance.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>manicure and pedicure</span>
            <div class="service-container">
                <img src="images\manicure&pedicure.jfif" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Treat yourself to luxurious manicures and pedicures at our salon. Our skilled nail technicians offer a range of services to pamper your hands and feet and leave them looking and feeling beautiful.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li> Keep your nails looking polished and well-groomed with regular manicures and pedicures.</li>
                        <li>Enjoy a relaxing and rejuvenating experience that includes soaking, exfoliating, and massage.</li>
                        <li>Choose from a wide variety of nail colors, finishes, and designs to express your style and personality.</li>
                        <li>Maintain the health of your nails and cuticles with professional-grade products and techniques.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Manicures: Nail shaping, cuticle care, hand massage, and polish application.</li>
                        <li>Pedicures: Foot soak, callus removal, nail trimming, and massage.</li>
                        <li>Gel Nails: Long-lasting and chip-resistant gel polish for durable and glossy nails.</li>
                        <li>Nail Art: Creative designs, embellishments, and patterns to add flair to your nails.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>waxing Salon</span>
            <div class="service-container">
                <img src="images\waxing--salon.jfif" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Experience smooth and silky skin with our waxing services. Our skilled estheticians provide gentle and effective hair removal treatments to help you achieve long-lasting results and silky-smooth skin.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Enjoy smooth and hair-free skin for weeks without the hassle of daily shaving.</li>
                        <li>Experience minimal discomfort with our gentle waxing techniques and high-quality products.</li>
                        <li>Say goodbye to ingrown hairs and stubble for a cleaner and more polished look.</li>
                        <li>Choose from a variety of waxing options to suit your needs, including full body, facial, and intimate waxing services.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Body Waxing: Hair removal for arms, legs, back, chest, and other areas.</li>
                        <li>Facial Waxing: Eyebrows, lip, chin, and full face waxing to remove unwanted facial hair.</li>
                        <li>Brazilian Waxing: Complete hair removal in the bikini area for a smooth and clean look.</li>
                        <li>Aftercare: Soothing post-waxing treatments and products to calm and hydrate the skin.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Gym and fitness</span>
            <div class="service-container">
                <img src="images\gym and fitness.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Achieve your fitness goals and lead a healthier lifestyle with our gym and fitness center. Our state-of-the-art facilities, experienced trainers, and diverse range of classes are designed to help you reach your full potential.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Access to cutting-edge equipment and facilities to support your fitness journey.</li>
                        <li>Work with certified personal trainers who provide individualized workouts and support.</li>
                        <li>Participate in a variety of group fitness classes for motivation, accountability, and fun.</li>
                        <li>Enjoy a supportive and inclusive community that encourages and inspires you to succeed.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Cardio: Treadmills, ellipticals, stationary bikes, and rowing machines for cardiovascular fitness.</li>
                        <li>Strength Training: Free weights, machines, and functional training equipment to build muscle and strength.</li>
                        <li>Group Classes: Yoga, Pilates, HIIT, Zumba, cycling, and more to keep you engaged and motivated.</li>
                        <li>Personal Training: Customized workouts, nutrition guidance, and accountability to help you reach your goals.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Weight Loss</span>
            <div class="service-container">
                <img src="images\weight loss.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Take control of your weight and improve your health with our weight loss programs. Our team of experts provides comprehensive support, guidance, and resources to help you achieve sustainable weight loss and long-term success.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Receive personalized assessments and recommendations to create a tailored weight loss plan.</li>
                        <li>Learn practical strategies for healthy eating, portion control, and lifestyle modifications.</li>
                        <li>Access to ongoing support, coaching, and accountability to stay on track and overcome obstacles.</li>
                        <li>Celebrate your progress and achievements in a supportive and non-judgmental environment.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Nutritional Counseling: Individualized meal plans, dietary recommendations, and behavior modification strategies.</li>
                        <li>Fitness Coaching: Exercise prescriptions, workout plans, and fitness assessments to support your weight loss goals.</li>
                        <li>Behavior Modification: Cognitive-behavioral techniques, mindfulness practices, and habit-building strategies.</li>
                        <li>Medical Support: Physician oversight, medication management, and medical interventions as needed.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Personal Trainer</span>
            <div class="service-container">
                <img src="images\personal trainer.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Maximize your fitness potential with the guidance of a certified personal trainer. Our trainers provide personalized workouts, coaching, and support to help you achieve your fitness goals safely and effectively.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Receive individualized workouts tailored to your fitness level, goals, and preferences.</li>
                        <li>Learn proper exercise techniques, form, and safety guidelines to prevent injuries and maximize results.</li>
                        <li>Stay motivated and accountable with ongoing support, encouragement, and progress tracking.</li>
                        <li>Achieve faster and more sustainable results with expert guidance and accountability.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Initial Assessment: Fitness evaluation, goal-setting, and health history review to create a personalized plan.</li>
                        <li>Custom Workouts: Tailored exercise programs designed to target your specific needs and objectives.</li>
                        <li>Form Correction: Instruction and feedback to ensure proper technique and minimize the risk of injury.</li>
                        <li>Progress Tracking: Regular assessments, measurements, and adjustments to track your progress and keep you on track.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Make Up</span>
            <div class="service-container">
                <img src="images\make-up.jpg" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Enhance your natural beauty and boost your confidence with our professional makeup services. Whether you're preparing for a special occasion, photo shoot, or simply want to refresh your look, our talented makeup artists are here to help you look and feel your best.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Transform your appearance with expertly applied makeup that highlights your best features.</li>
                        <li>Choose from a variety of makeup looks ranging from natural and subtle to bold and glamorous.</li>
                        <li>Receive personalized recommendations and tips for makeup products, colors, and techniques.</li>
                        <li>Enjoy a relaxing and pampering experience in our salon or on-site for your convenience.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Special Occasion Makeup: Bridal, prom, and event makeup for a flawless and long-lasting look.</li>
                        <li> Editorial Makeup: Creative and artistic makeup for photo shoots, fashion shows, and editorial work.</li>
                        <li>Everyday Makeup: Natural and polished makeup for everyday wear that enhances your natural beauty.</li>
                        <li>Makeup Lessons: Individual or group lessons to learn makeup application techniques and tips from our experts.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

   
    <div class="service" id="service">
        <div class="container">
            <span>Skincare Treatments</span>
            <div class="service-container">
                <img src="images\skin-care-treatments.jfif" alt="">
                <div class="service-box">
                    <p><strong>Description:</strong>Achieve radiant and youthful-looking skin with our range of skincare treatments. Whether you're concerned about acne, aging, or maintaining a healthy complexion, our skilled estheticians are dedicated to providing personalized solutions to help you achieve your skincare goals.<p>
                    <p><strong>Benefits:</strong><p>
                    <ul>
                        <li>Improve skin texture, tone, and clarity for a smoother and more luminous complexion.</li>
                        <li>Address specific skincare concerns such as acne, hyperpigmentation, and fine lines.</li>
                        <li>Customized treatment plans tailored to your skin type, concerns, and lifestyle.</li>
                        <li>Relaxing and rejuvenating treatments that leave your skin feeling refreshed and revitalized.</li>
                    </ul>
                    <p><strong>Features:</strong></p>
                    <ul>
                        <li>Facials: Deep cleansing, exfoliation, and hydration to restore and rejuvenate the skin.</li>
                        <li>Chemical Peels: Exfoliating treatments to improve skin texture, reduce fine lines, and even out skin tone.</li>
                        <li>Microdermabrasion: Mechanical exfoliation to remove dead skin cells and promote cell turnover.</li>
                        <li>Acne Treatments: Targeted therapies to reduce inflammation, unclog pores, and prevent future breakouts.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
 
</body>
</html>
