<?php
include('db_config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $rating = $_POST["rating"];
    $comment = $_POST["comment"];

    // Check if file was uploaded successfully
    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["photo"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["photo"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        $allowed_formats = array("jpg", "jpeg", "png", "gif");
        if (!in_array($imageFileType, $allowed_formats)) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                echo "<p>The file ". htmlspecialchars( basename( $_FILES["photo"]["name"])). " has been uploaded.</p>";

                // Read the contents of the uploaded image file and insert it into the database
                $photo_data = file_get_contents($target_file);

                $sql = "INSERT INTO reviews (username, rating, comment, photo) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("sssb", $username, $rating, $comment, $photo_data);

                    if ($stmt->execute()) {
                        echo "<p>Thank you, $username! Your review has been submitted successfully.</p>";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }

                    $stmt->close();
                }

            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        echo "Error uploading file. Please try again.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Review - Mobile Beauty & Therapy</title>
    <link rel="stylesheet" href="logins.css">
    
</head>
<body>

    <header>
        <h1>MOBILE BEAUTY AND THERAPY <span>MAKE REVIEW</span></h1>

        <nav>
            <ul>
                <a href="reviews.php">Made reviews</a>
            </ul>
        </nav>
    </header>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
        <label for="username">Your username:</label>
        <input type="text" id="username" name="username" required>

        <label for="photo">Upload a photo:</label>
        <input type="file" id="photo" name="photo" accept="image/*" required>

        <label for="rating">Rating:</label>
        <select id="rating" name="rating" required>
            <option value="5">5 - Excellent</option>
            <option value="4">4 - Very Good</option>
            <option value="3">3 - Good</option>
            <option value="2">2 - Fair</option>
            <option value="1">1 - Poor</option>
        </select>

        <label for="comment">Your Review:</label>
        <textarea id="comment" name="comment" rows="4" required></textarea>

        <button type="submit">Submit Review</button>
    </form>

    <!-- Add a link to view existing reviews if needed -->

</body>
</html>
