<?php
session_start();


// Include database connection file
include "db_config.php";

// Check if appointment_id is provided
if(isset($_GET['appointment_id'])) {
    $appointmentId = $_GET['appointment_id'];
    
    // Update appointment status to Declined
    $sql = "UPDATE appointments SET status = 'Declined' WHERE appointment_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $appointmentId);
    
    if ($stmt->execute()) {
        // Redirect back to appointments page
        header("Location: appointments.php");
        exit();
    } else {
        echo "Error declining appointment: " . $stmt->error;
    }
} else {
    echo "Appointment ID not provided.";
}

