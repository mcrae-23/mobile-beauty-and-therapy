
// add hovered class to selected list item
let list = document.querySelectorAll(".navigation li");

function activelink(){
    list.forEach((item) =>{
        item.class.remove("hovered");
    })
    this.classlist.add("hovered");
}

list.forEach(item => item.addEventListener("mouseover",activelink ))

let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");
let main = document.querySelector(".main");

toggle.onclick = function(){
    navigation.classList.toggle("active");
    main.classList.toggle("active");
};

// payment method
document.addEventListener('DOMContentLoaded', function () {
    // Set your Stripe publishable key
    const stripe = Stripe('YOUR_STRIPE_PUBLIC_KEY');
    const elements = stripe.elements();

    // Create an instance of the card Element
    const card = elements.create('card');

    // Add an instance of the card Element into the `cardElement` div
    card.mount('#cardElement');

    // Handle form submission
    const form = document.getElementById('paymentForm');
    form.addEventListener('submit', function (event) {
        event.preventDefault();

        stripe.createToken(card).then(function (result) {
            if (result.error) {
                // Inform the user if there was an error
                alert(result.error.message);
            } else {
                // Send the token to your server
                handlePayment(result.token);
            }
        });
    });

    // Function to handle payment on the server
    function handlePayment(token) {
        const amount = document.getElementById('amount').value;

        // Send token and amount to server using AJAX or fetch
        // For simplicity, I'll use fetch in this example
        fetch('process-payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                token: token.id,
                amount: amount,
            }),
        })
        .then(response => response.json())
        .then(data => {
            // Display the payment result to the user
            const paymentResult = document.getElementById('paymentResult');
            paymentResult.innerHTML = data.success ? 'Payment successful!' : 'Payment failed.';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing the payment.');
        });
    }
});
