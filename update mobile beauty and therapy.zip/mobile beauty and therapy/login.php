<?php
// Start session to maintain user login state
session_start();

// Include database connection file
include "db_config.php"; // Assuming this file contains code to connect to your database

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sanitize inputs to prevent SQL injection
    $username = htmlspecialchars($username); // You may also use htmlspecialchars for basic sanitization
    // Note: Do not sanitize password as it will be hashed

    // Query to fetch user details from the database
    $sql = "SELECT * FROM users WHERE username=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $user['id'];
            // Redirect to home page or any other page
            header("Location: home.php");
            exit();
        } else {
            // Invalid password
            $error = "Invalid username or password";
        }
    } else {
        // No user with the given username exists
        $error = "Invalid username or password";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mobile Beauty & Therapy</title>
    <link rel="stylesheet" href="logins.css">
    <style>
        /* Your styles go here */
    </style>
</head>
<body>
    <header>
    <h2>LOGIN</h2>
    <nav>
        <ul>
            <a href="home.php">Home</a>
            <a href="register.php">Register</a>
        </ul>
    </nav>
 
    </header>
 
    

    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>

        <?php
            if (isset($error)) {
                echo '<p style="color: black;">' . $error . '</p>';
            }
        ?>
    </form>

    

    <!-- Add a link to the registration page if needed -->

</body>
</html>

    

