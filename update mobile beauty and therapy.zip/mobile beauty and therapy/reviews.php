<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Reviews</title>
    <style>

        :root{
            --blue:#00b8b8;
            --black:#333;
            --white:#ffff;
            --light-color:lightgrey;
            --light-bg:#eeee;
            --border:.2rem solid rgba(0,0,0,.1);
            --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);

        }

        *{
            font-family: Arial, Helvetica, sans-serif;
            margin:0;
            padding:0;
            box-sizing: border-box;
            outline:none;
            border:none;
            text-decoration: none;
            text-transform: capitalize;
        }
        *::-webkit-scrollbar{
            height: .5rem;
            width: 1rem;
        }
        *::-webkit-scrollbar-track{
            background-color: transparent;
        }
        *::-webkit-scrollbar-thumb{
            background-color: aqua;
            border-radius: 5px;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header{
            background-color: #00b8b8;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            font-size: 1.5rem;
        }

        h1 {
            text-align: center;
            margin-top: 10px;
            color: #ffff;

        }
        .container {
            width: 80%;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Adjust the minmax values as needed */
            grid-gap: 20px;
            padding: 20px;
        }

        .container div {
            border: 1px solid #ccc;
            padding: 10px;
        }



        .container p {
            margin: 0;
        }

        .container p strong {
            font-weight: bold;
        }

        .container p:first-child {
            margin-bottom: 10px;
        }

        .container p:last-child {
            margin-top: 10px;
        }

      
    </style>
</head>
<body>
    <header>
      <h1>User Reviews</h1>
    </header>
   

    <div class="container">
        <?php
        // Include database connection file
        include "db_config.php"; // Assuming this file contains code to connect to your database

        // Fetch reviews from the database
        $sql = "SELECT * FROM reviews";
        $result = mysqli_query($conn, $sql);

        // Check if there are any reviews
        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div>";
                echo "<p><strong>Reviewer:</strong> " . $row['username'] . "</p>";
                echo "<p><strong>Review:</strong> " . $row['comment'] . "</p>";
                // Display admin reply if available
                if (!empty($row['admin_reply'])) {
                    echo "<p><strong>Admin Reply:</strong> " . $row['admin_reply'] . "</p>";
                }
                echo "</div>";
            }
        } else {
            echo "<p>No reviews found.</p>";
        }
        ?>
    </div>
</body>
</html>
